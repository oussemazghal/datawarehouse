package routines;

public class routine1 {

    /**
     * Remplace les trois premières lettres d'une chaîne par le nom complet de la ville ou du pays correspondant.
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string input: La chaîne de caractères à traiter.
     * 
     * {example} replaceWithFullName("Tou") # "Toulouse"
     * {example} replaceWithFullName("Lon") # "London"
     */
    public static String replaceWithFullName(String input) {
        if (input == null || input.length() < 3) {
            return input; // Retourne la chaîne d'origine si elle est nulle ou trop courte.
        }
        
        String prefix = input.substring(0, 3).toLowerCase();
        switch (prefix) {
            case "par":
                return "Paris";
            case "lyo":
                return "Lyon";
            case "nic":
                return "Nice";
            case "tou":
                return "Toulouse";
            case "mar":
                return "Marseille";
            case "bir":
                return "Birmingham";
            case "man":
                return "Manchester";
            case "lee":
                return "Leeds";
            case "liv":
                return "Liverpool";
            case "lon":
                return "London";
            default:
                return input; // Retourne la chaîne d'origine si aucun préfixe ne correspond.
        }
    }

    /**
     * Retourne la tranche d'âge sous forme de chaîne en fonction de l'âge entier donné en entrée.
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} int age: L'âge de la personne.
     * 
     * {example} getAgeRange(28) # "19-30"
     * {example} getAgeRange(45) # "41-50"
     */
    public static String getAgeRange(int age) {
        if (age <= 18) {
            return "0-18";
        } else if (age <= 30) {
            return "19-30";
        } else if (age <= 40) {
            return "31-40";
        } else if (age <= 50) {
            return "41-50";
        } else if (age <= 60) {
            return "51-60";
        } else {
            return "61+";
        }
    }

public static String getWeightRange(float weight) {
    if (weight <= 50) {
        return "0-50";
    } else if (weight <= 60) {
        return "51-60";
    } else if (weight <= 70) {
        return "61-70";
    } else if (weight <= 80) {
        return "71-80";
    } else if (weight <= 90) {
        return "81-90";
    } else {
        return "91+";
    }
}
public static int multiplyAndRound(double value ) {
    double result = value * 60;
    
        return (int) Math.floor(result); // Arrondit vers le bas
    }
public static int divideAndRound(float value) {
    float result = value / 3;
    
        
            return (int) Math.floor(result); // Arrondi inférieur
        
}
public static String capitalizeFirstLetter(String input) {
    if (input == null || input.isEmpty()) {
        return input; // Retourne la chaîne d'origine si elle est nulle ou vide.
    }
    
    // Met la première lettre en majuscule et le reste en minuscule
    return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
}

}
