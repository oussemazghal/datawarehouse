package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class test2 {

    /**
     * helloExample: prints "hello" followed by the input message.
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string to be printed.
     * 
     * {example} helloExample("world") # hello world !
     */
    public static void helloExample(String message) {
        System.out.println("hello " + message);  // Prints the message with 'hello' before it
    }

    /**
     * convertToBoolean: Converts the string "No" to false, anything else to true.
     * 
     * {talendTypes} Boolean
     * 
     * {Category} User Defined
     * 
     * {param} string input: The string to be converted to a boolean.
     * 
     * {example} convertToBoolean("No") # false
     * {example} convertToBoolean("Yes") # true
     */
    public static boolean convertToBoolean(String smokes) {
        if ("No".equals(smokes)) {  // Compare strings using .equals()
            return false; // Return false if the input is "No"
        } else {
            return true;  // Otherwise return true
        }
    }
    public static boolean convertToBoolean1(int smokes) {
        if (smokes==0) {  // Compare strings using .equals()
            return false; // Return false if the input is "No"
        } else {
            return true;  // Otherwise return true
        }
    }

    public static void main(String[] args) {
        helloExample("world");  // Example usage of helloExample

        System.out.println(convertToBoolean("No"));  // Example usage of convertToBoolean
        System.out.println(convertToBoolean("Yes"));
    }
}
