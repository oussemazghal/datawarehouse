// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package projet_data.job2_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.test2;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.routine1;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: job2 Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class job2 implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "job2";
	private final String projectName = "PROJET_DATA";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					job2.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(job2.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tUnite_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputJSON_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row6Struct other = (row6Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row6Struct other) {

			other.id = this.id;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;
			other.doctor_age = this.doctor_age;
			other.specialty = this.specialty;
			other.experience = this.experience;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_age = this.person_age;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;
			other.weight = this.weight;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(row6Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row6Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class ssStruct implements routines.system.IPersistableRow<ssStruct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final ssStruct other = (ssStruct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(ssStruct other) {

			other.id = this.id;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;
			other.doctor_age = this.doctor_age;
			other.specialty = this.specialty;
			other.experience = this.experience;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_age = this.person_age;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;
			other.weight = this.weight;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(ssStruct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ssStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row3Struct other = (row3Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row3Struct other) {

			other.id = this.id;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;
			other.doctor_age = this.doctor_age;
			other.specialty = this.specialty;
			other.experience = this.experience;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_age = this.person_age;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;
			other.weight = this.weight;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(row3Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OUT1Struct implements routines.system.IPersistableRow<OUT1Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OUT1Struct other = (OUT1Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OUT1Struct other) {

			other.id = this.id;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;
			other.doctor_age = this.doctor_age;
			other.specialty = this.specialty;
			other.experience = this.experience;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_age = this.person_age;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;
			other.weight = this.weight;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(OUT1Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OUT1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_nam;

		public String getDoctor_first_nam() {
			return this.doctor_first_nam;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public String practice_sport;

		public String getPractice_sport() {
			return this.practice_sport;
		}

		public String smokes;

		public String getSmokes() {
			return this.smokes;
		}

		public String alcohol;

		public String getAlcohol() {
			return this.alcohol;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_nam = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					this.practice_sport = readString(dis);

					this.smokes = readString(dis);

					this.alcohol = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_nam = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					this.practice_sport = readString(dis);

					this.smokes = readString(dis);

					this.alcohol = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_nam, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// String

				writeString(this.practice_sport, dos);

				// String

				writeString(this.smokes, dos);

				// String

				writeString(this.alcohol, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_nam, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// String

				writeString(this.practice_sport, dos);

				// String

				writeString(this.smokes, dos);

				// String

				writeString(this.alcohol, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_nam=" + doctor_first_nam);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + practice_sport);
			sb.append(",smokes=" + smokes);
			sb.append(",alcohol=" + alcohol);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OUT111Struct implements routines.system.IPersistableRow<OUT111Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final OUT111Struct other = (OUT111Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(OUT111Struct other) {

			other.id = this.id;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;
			other.doctor_age = this.doctor_age;
			other.specialty = this.specialty;
			other.experience = this.experience;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_age = this.person_age;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;
			other.weight = this.weight;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(OUT111Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OUT111Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date consultation_date;

		public java.util.Date getConsultation_date() {
			return this.consultation_date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String speciality;

		public String getSpeciality() {
			return this.speciality;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public String practice_sport;

		public String getPractice_sport() {
			return this.practice_sport;
		}

		public String smokes;

		public String getSmokes() {
			return this.smokes;
		}

		public String alcohol;

		public String getAlcohol() {
			return this.alcohol;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.consultation_date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.speciality = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					this.practice_sport = readString(dis);

					this.smokes = readString(dis);

					this.alcohol = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.consultation_date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.speciality = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					this.practice_sport = readString(dis);

					this.smokes = readString(dis);

					this.alcohol = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.consultation_date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.speciality, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// String

				writeString(this.practice_sport, dos);

				// String

				writeString(this.smokes, dos);

				// String

				writeString(this.alcohol, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.consultation_date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.speciality, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// String

				writeString(this.practice_sport, dos);

				// String

				writeString(this.smokes, dos);

				// String

				writeString(this.alcohol, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",consultation_date=" + String.valueOf(consultation_date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",speciality=" + speciality);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + practice_sport);
			sb.append(",smokes=" + smokes);
			sb.append(",alcohol=" + alcohol);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class kkkStruct implements routines.system.IPersistableRow<kkkStruct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final kkkStruct other = (kkkStruct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(kkkStruct other) {

			other.id = this.id;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;
			other.doctor_age = this.doctor_age;
			other.specialty = this.specialty;
			other.experience = this.experience;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_age = this.person_age;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;
			other.weight = this.weight;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(kkkStruct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(kkkStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_job2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_job2 = new byte[0];

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_job2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_job2.length == 0) {
						commonByteArray_PROJET_DATA_job2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_job2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_job2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_job2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_job2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

					this.doctor_age = readInteger(dis);

					this.specialty = readString(dis);

					this.experience = readInteger(dis);

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.person_age = readInteger(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.weight = null;
					} else {
						this.weight = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.practice_sport = null;
					} else {
						this.practice_sport = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.smokes = null;
					} else {
						this.smokes = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.alcohol = null;
					} else {
						this.alcohol = dis.readBoolean();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

				// Integer

				writeInteger(this.doctor_age, dos);

				// String

				writeString(this.specialty, dos);

				// Integer

				writeInteger(this.experience, dos);

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// Integer

				writeInteger(this.person_age, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

				// Float

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				// Boolean

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				// Boolean

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				// Boolean

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				OUT1Struct OUT1 = new OUT1Struct();

				row2Struct row2 = new row2Struct();
				OUT111Struct OUT111 = new OUT111Struct();

				row5Struct row5 = new row5Struct();
				kkkStruct kkk = new kkkStruct();

				row3Struct row3 = new row3Struct();
				row4Struct row4 = new row4Struct();
				ssStruct ss = new ssStruct();
				ssStruct row6 = ss;

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row6");
				}

				int tos_count_tLogRow_1 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_1 = "|";
				java.io.PrintStream consoleOut_tLogRow_1 = null;

				StringBuilder strBuffer_tLogRow_1 = null;
				int nb_line_tLogRow_1 = 0;
///////////////////////    			

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_1", false);
				start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileOutputDelimited_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "ss");
				}

				int tos_count_tFileOutputDelimited_1 = 0;

				String fileName_tFileOutputDelimited_1 = "";
				fileName_tFileOutputDelimited_1 = (new java.io.File(
						"C:\\Users\\pc\\Desktop\\projet datawarehouse\\toussss.csv")).getAbsolutePath().replace("\\",
								"/");
				String fullName_tFileOutputDelimited_1 = null;
				String extension_tFileOutputDelimited_1 = null;
				String directory_tFileOutputDelimited_1 = null;
				if ((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
							fileName_tFileOutputDelimited_1.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					}
					directory_tFileOutputDelimited_1 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_1 = true;
				java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);
				if (filetFileOutputDelimited_1.exists()) {
					throw new RuntimeException("The particular file \"" + filetFileOutputDelimited_1.getAbsoluteFile()
							+ "\" already exist. If you want to overwrite the file, please uncheck the"
							+ " \"Throw an error if the file already exist\" option in Advanced settings.");
				}
				int nb_line_tFileOutputDelimited_1 = 0;
				int splitedFileNo_tFileOutputDelimited_1 = 0;
				int currentRow_tFileOutputDelimited_1 = 0;

				final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */
						","/** End field tFileOutputDelimited_1:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /**
																		 * Start field
																		 * tFileOutputDelimited_1:ROWSEPARATOR
																		 */
						"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
					if (!dir_tFileOutputDelimited_1.exists()) {
						dir_tFileOutputDelimited_1.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_1 = null;

				java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				if (fileToDelete_tFileOutputDelimited_1.exists()) {
					fileToDelete_tFileOutputDelimited_1.delete();
				}
				outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false), "ISO-8859-15"));
				if (filetFileOutputDelimited_1.length() == 0) {
					outtFileOutputDelimited_1.write("id");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("date");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("price");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("duration");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("doctor_first_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("doctor_last_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("doctor_age");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("specialty");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("experience");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("hospital_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("city");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("country");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("person_first_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("person_last_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("person_age");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("job");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("marital_status");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("gender");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("weight");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("practice_sport");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("smokes");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("alcohol");
					outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.flush();
				}

				resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
				resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

				/**
				 * [tFileOutputDelimited_1 begin ] stop
				 */

				/**
				 * [tMap_4 begin ] start
				 */

				ok_Hash.put("tMap_4", false);
				start_Hash.put("tMap_4", System.currentTimeMillis());

				currentComponent = "tMap_4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row4");
				}

				int tos_count_tMap_4 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_4__Struct {
				}
				Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				ssStruct ss_tmp = new ssStruct();
// ###############################

				/**
				 * [tMap_4 begin ] stop
				 */

				/**
				 * [tFilterRow_1 begin ] start
				 */

				ok_Hash.put("tFilterRow_1", false);
				start_Hash.put("tFilterRow_1", System.currentTimeMillis());

				currentComponent = "tFilterRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tFilterRow_1 = 0;

				int nb_line_tFilterRow_1 = 0;
				int nb_line_ok_tFilterRow_1 = 0;
				int nb_line_reject_tFilterRow_1 = 0;

				class Operator_tFilterRow_1 {
					private String sErrorMsg = "";
					private boolean bMatchFlag = true;
					private String sUnionFlag = "&&";

					public Operator_tFilterRow_1(String unionFlag) {
						sUnionFlag = unionFlag;
						bMatchFlag = "||".equals(unionFlag) ? false : true;
					}

					public String getErrorMsg() {
						if (sErrorMsg != null && sErrorMsg.length() > 1)
							return sErrorMsg.substring(1);
						else
							return null;
					}

					public boolean getMatchFlag() {
						return bMatchFlag;
					}

					public void matches(boolean partMatched, String reason) {
						// no need to care about the next judgement
						if ("||".equals(sUnionFlag) && bMatchFlag) {
							return;
						}

						if (!partMatched) {
							sErrorMsg += "|" + reason;
						}

						if ("||".equals(sUnionFlag))
							bMatchFlag = bMatchFlag || partMatched;
						else
							bMatchFlag = bMatchFlag && partMatched;
					}
				}

				/**
				 * [tFilterRow_1 begin ] stop
				 */

				/**
				 * [tUnite_1 begin ] start
				 */

				ok_Hash.put("tUnite_1", false);
				start_Hash.put("tUnite_1", System.currentTimeMillis());

				currentComponent = "tUnite_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "OUT1", "OUT111", "kkk");
				}

				int tos_count_tUnite_1 = 0;

				int nb_line_tUnite_1 = 0;

				/**
				 * [tUnite_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				OUT1Struct OUT1_tmp = new OUT1Struct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_2", false);
				start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_2";

				int tos_count_tFileInputDelimited_2 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try {

					Object filename_tFileInputDelimited_2 = "C:\\Users\\pc\\Desktop\\projet datawarehouse\\fichier_sans_2023.csv";
					if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
						if (footer_value_tFileInputDelimited_2 > 0 || random_value_tFileInputDelimited_2 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(
								"C:\\Users\\pc\\Desktop\\projet datawarehouse\\fichier_sans_2023.csv", "ISO-8859-15",
								",", "\n", true, 1, 0, limit_tFileInputDelimited_2, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_2 != null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();

						row1 = null;

						boolean whetherReject_tFileInputDelimited_2 = false;
						row1 = new row1Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_2 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_2 = 0;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.id = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"id", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}

							} else {

								row1.id = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 1;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.date = ParserUtils.parseTo_Date(temp, "yyyy-MM-dd");

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"date", "row1", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}

							} else {

								row1.date = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 2;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.price = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"price", "row1", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row1.price = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 3;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.duration = ParserUtils.parseTo_Double(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"duration", "row1", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row1.duration = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 4;

							row1.doctor_first_nam = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 5;

							row1.doctor_last_name = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 6;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.doctor_age = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"doctor_age", "row1", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row1.doctor_age = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 7;

							row1.specialty = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 8;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.experience = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"experience", "row1", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row1.experience = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 9;

							row1.hospital_name = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 10;

							row1.city = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 11;

							row1.country = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 12;

							row1.person_first_name = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 13;

							row1.person_last_name = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 14;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.person_age = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"person_age", "row1", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row1.person_age = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 15;

							row1.job = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 16;

							row1.marital_status = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 17;

							row1.gender = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 18;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									row1.weight = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"weight", "row1", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								row1.weight = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 19;

							row1.practice_sport = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 20;

							row1.smokes = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 21;

							row1.alcohol = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							if (rowstate_tFileInputDelimited_2.getException() != null) {
								throw rowstate_tFileInputDelimited_2.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_2 = true;

							System.err.println(e.getMessage());
							row1 = null;

						}

						/**
						 * [tFileInputDelimited_2 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_2 main ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						tos_count_tFileInputDelimited_2++;

						/**
						 * [tFileInputDelimited_2 main ] stop
						 */

						/**
						 * [tFileInputDelimited_2 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
								// ###############################
								// # Output tables

								OUT1 = null;

// # Output table : 'OUT1'
								OUT1_tmp.id = row1.id;
								OUT1_tmp.date = row1.date;
								OUT1_tmp.price = row1.price;
								OUT1_tmp.duration = row1.duration;
								OUT1_tmp.doctor_first_name = row1.doctor_first_nam;
								OUT1_tmp.doctor_last_name = row1.doctor_last_name;
								OUT1_tmp.doctor_age = row1.doctor_age;
								OUT1_tmp.specialty = row1.specialty;
								OUT1_tmp.experience = row1.experience;
								OUT1_tmp.hospital_name = row1.hospital_name;
								OUT1_tmp.city = row1.city;
								OUT1_tmp.country = row1.country;
								OUT1_tmp.person_first_name = row1.person_first_name;
								OUT1_tmp.person_last_name = row1.person_last_name;
								OUT1_tmp.person_age = row1.person_age;
								OUT1_tmp.job = row1.job;
								OUT1_tmp.marital_status = row1.marital_status;
								OUT1_tmp.gender = row1.gender;
								OUT1_tmp.weight = row1.weight;
								OUT1_tmp.practice_sport = routines.test2.convertToBoolean(row1.practice_sport);
								OUT1_tmp.smokes = routines.test2.convertToBoolean(row1.smokes);
								OUT1_tmp.alcohol = routines.test2.convertToBoolean(row1.alcohol);
								OUT1 = OUT1_tmp;
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_1 = false;

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "OUT1"
							if (OUT1 != null) {

								/**
								 * [tUnite_1 main ] start
								 */

								currentComponent = "tUnite_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "OUT1"

									);
								}

//////////

// for output
								row3 = new row3Struct();

								row3.id = OUT1.id;
								row3.date = OUT1.date;
								row3.price = OUT1.price;
								row3.duration = OUT1.duration;
								row3.doctor_first_name = OUT1.doctor_first_name;
								row3.doctor_last_name = OUT1.doctor_last_name;
								row3.doctor_age = OUT1.doctor_age;
								row3.specialty = OUT1.specialty;
								row3.experience = OUT1.experience;
								row3.hospital_name = OUT1.hospital_name;
								row3.city = OUT1.city;
								row3.country = OUT1.country;
								row3.person_first_name = OUT1.person_first_name;
								row3.person_last_name = OUT1.person_last_name;
								row3.person_age = OUT1.person_age;
								row3.job = OUT1.job;
								row3.marital_status = OUT1.marital_status;
								row3.gender = OUT1.gender;
								row3.weight = OUT1.weight;
								row3.practice_sport = OUT1.practice_sport;
								row3.smokes = OUT1.smokes;
								row3.alcohol = OUT1.alcohol;

								nb_line_tUnite_1++;

//////////

								tos_count_tUnite_1++;

								/**
								 * [tUnite_1 main ] stop
								 */

								/**
								 * [tUnite_1 process_data_begin ] start
								 */

								currentComponent = "tUnite_1";

								/**
								 * [tUnite_1 process_data_begin ] stop
								 */

								/**
								 * [tFilterRow_1 main ] start
								 */

								currentComponent = "tFilterRow_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row3"

									);
								}

								row4 = null;
								Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");
								ope_tFilterRow_1.matches(
										(row3.id == null ? false
												: row3.id.compareTo(
														ParserUtils.parseTo_Integer(String.valueOf(0))) != 0),
										"id.compareTo(0) != 0 failed");

								ope_tFilterRow_1
										.matches(
												(row3.duration == null ? false
														: row3.duration.compareTo(
																ParserUtils.parseTo_Double(String.valueOf(0))) != 0),
												"duration.compareTo(0) != 0 failed");

								ope_tFilterRow_1
										.matches(
												(row3.duration == null ? false
														: row3.duration.compareTo(
																ParserUtils.parseTo_Double(String.valueOf(0))) != 0),
												"duration.compareTo(0) != 0 failed");

								ope_tFilterRow_1.matches(
										(row3.doctor_first_name == null ? false
												: row3.doctor_first_name.compareTo("") != 0),
										"doctor_first_name.compareTo(\"\") != 0 failed");
								ope_tFilterRow_1.matches(
										((row3.id != null) && (row3.date != null) && (row3.price != null)
												&& (row3.duration != null)
												&& (row3.doctor_first_name != null
														&& !row3.doctor_first_name.isEmpty())),
										"advanced condition failed");

								if (ope_tFilterRow_1.getMatchFlag()) {
									if (row4 == null) {
										row4 = new row4Struct();
									}
									row4.id = row3.id;
									row4.date = row3.date;
									row4.price = row3.price;
									row4.duration = row3.duration;
									row4.doctor_first_name = row3.doctor_first_name;
									row4.doctor_last_name = row3.doctor_last_name;
									row4.doctor_age = row3.doctor_age;
									row4.specialty = row3.specialty;
									row4.experience = row3.experience;
									row4.hospital_name = row3.hospital_name;
									row4.city = row3.city;
									row4.country = row3.country;
									row4.person_first_name = row3.person_first_name;
									row4.person_last_name = row3.person_last_name;
									row4.person_age = row3.person_age;
									row4.job = row3.job;
									row4.marital_status = row3.marital_status;
									row4.gender = row3.gender;
									row4.weight = row3.weight;
									row4.practice_sport = row3.practice_sport;
									row4.smokes = row3.smokes;
									row4.alcohol = row3.alcohol;
									nb_line_ok_tFilterRow_1++;
								} else {
									nb_line_reject_tFilterRow_1++;
								}

								nb_line_tFilterRow_1++;

								tos_count_tFilterRow_1++;

								/**
								 * [tFilterRow_1 main ] stop
								 */

								/**
								 * [tFilterRow_1 process_data_begin ] start
								 */

								currentComponent = "tFilterRow_1";

								/**
								 * [tFilterRow_1 process_data_begin ] stop
								 */
// Start of branch "row4"
								if (row4 != null) {

									/**
									 * [tMap_4 main ] start
									 */

									currentComponent = "tMap_4";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "row4"

										);
									}

									boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

									// ###############################
									// # Input tables (lookups)
									boolean rejectedInnerJoin_tMap_4 = false;
									boolean mainRowRejected_tMap_4 = false;

									// ###############################
									{ // start of Var scope

										// ###############################
										// # Vars tables

										Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
										// ###############################
										// # Output tables

										ss = null;

// # Output table : 'ss'
										ss_tmp.id = row3.id;
										ss_tmp.date = row3.date;
										ss_tmp.price = row3.price;
										ss_tmp.duration = row3.duration;
										ss_tmp.doctor_first_name = routine1
												.capitalizeFirstLetter(row3.doctor_first_name);
										ss_tmp.doctor_last_name = routine1.capitalizeFirstLetter(row3.doctor_last_name);
										ss_tmp.doctor_age = row3.doctor_age;
										ss_tmp.specialty = routine1.capitalizeFirstLetter(row3.specialty);
										ss_tmp.experience = row3.experience;
										ss_tmp.hospital_name = routine1.capitalizeFirstLetter(row3.hospital_name);
										ss_tmp.city = routine1.capitalizeFirstLetter(row3.city);
										ss_tmp.country = routine1.capitalizeFirstLetter(row3.country);
										ss_tmp.person_first_name = routine1
												.capitalizeFirstLetter(row3.person_first_name);
										ss_tmp.person_last_name = routine1.capitalizeFirstLetter(row3.person_last_name);
										ss_tmp.person_age = row3.person_age;
										ss_tmp.job = routine1.capitalizeFirstLetter(row3.job);
										ss_tmp.marital_status = row3.marital_status;
										ss_tmp.gender = row3.gender;
										ss_tmp.weight = row3.weight;
										ss_tmp.practice_sport = row3.practice_sport;
										ss_tmp.smokes = row3.smokes;
										ss_tmp.alcohol = row3.alcohol;
										ss = ss_tmp;
// ###############################

									} // end of Var scope

									rejectedInnerJoin_tMap_4 = false;

									tos_count_tMap_4++;

									/**
									 * [tMap_4 main ] stop
									 */

									/**
									 * [tMap_4 process_data_begin ] start
									 */

									currentComponent = "tMap_4";

									/**
									 * [tMap_4 process_data_begin ] stop
									 */
// Start of branch "ss"
									if (ss != null) {

										/**
										 * [tFileOutputDelimited_1 main ] start
										 */

										currentComponent = "tFileOutputDelimited_1";

										if (execStat) {
											runStat.updateStatOnConnection(iterateId, 1, 1

													, "ss"

											);
										}

										StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
										if (ss.id != null) {
											sb_tFileOutputDelimited_1.append(ss.id);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.date != null) {
											sb_tFileOutputDelimited_1
													.append(FormatterUtils.format_Date(ss.date, "yyyy-MM-dd"));
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.price != null) {
											sb_tFileOutputDelimited_1.append(ss.price);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.duration != null) {
											sb_tFileOutputDelimited_1.append(ss.duration);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.doctor_first_name != null) {
											sb_tFileOutputDelimited_1.append(ss.doctor_first_name);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.doctor_last_name != null) {
											sb_tFileOutputDelimited_1.append(ss.doctor_last_name);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.doctor_age != null) {
											sb_tFileOutputDelimited_1.append(ss.doctor_age);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.specialty != null) {
											sb_tFileOutputDelimited_1.append(ss.specialty);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.experience != null) {
											sb_tFileOutputDelimited_1.append(ss.experience);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.hospital_name != null) {
											sb_tFileOutputDelimited_1.append(ss.hospital_name);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.city != null) {
											sb_tFileOutputDelimited_1.append(ss.city);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.country != null) {
											sb_tFileOutputDelimited_1.append(ss.country);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.person_first_name != null) {
											sb_tFileOutputDelimited_1.append(ss.person_first_name);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.person_last_name != null) {
											sb_tFileOutputDelimited_1.append(ss.person_last_name);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.person_age != null) {
											sb_tFileOutputDelimited_1.append(ss.person_age);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.job != null) {
											sb_tFileOutputDelimited_1.append(ss.job);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.marital_status != null) {
											sb_tFileOutputDelimited_1.append(ss.marital_status);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.gender != null) {
											sb_tFileOutputDelimited_1.append(ss.gender);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.weight != null) {
											sb_tFileOutputDelimited_1.append(ss.weight);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.practice_sport != null) {
											sb_tFileOutputDelimited_1.append(ss.practice_sport);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.smokes != null) {
											sb_tFileOutputDelimited_1.append(ss.smokes);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
										if (ss.alcohol != null) {
											sb_tFileOutputDelimited_1.append(ss.alcohol);
										}
										sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);

										nb_line_tFileOutputDelimited_1++;
										resourceMap.put("nb_line_tFileOutputDelimited_1",
												nb_line_tFileOutputDelimited_1);

										outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());

										row6 = ss;

										tos_count_tFileOutputDelimited_1++;

										/**
										 * [tFileOutputDelimited_1 main ] stop
										 */

										/**
										 * [tFileOutputDelimited_1 process_data_begin ] start
										 */

										currentComponent = "tFileOutputDelimited_1";

										/**
										 * [tFileOutputDelimited_1 process_data_begin ] stop
										 */

										/**
										 * [tLogRow_1 main ] start
										 */

										currentComponent = "tLogRow_1";

										if (execStat) {
											runStat.updateStatOnConnection(iterateId, 1, 1

													, "row6"

											);
										}

///////////////////////		

										strBuffer_tLogRow_1 = new StringBuilder();

										if (row6.id != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.id));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.date != null) { //

											strBuffer_tLogRow_1
													.append(FormatterUtils.format_Date(row6.date, "yyyy-MM-dd"));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.price != null) { //

											strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.price));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.duration != null) { //

											strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.duration));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.doctor_first_name != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_first_name));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.doctor_last_name != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_last_name));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.doctor_age != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_age));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.specialty != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.specialty));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.experience != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.experience));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.hospital_name != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.hospital_name));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.city != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.city));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.country != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.country));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.person_first_name != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.person_first_name));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.person_last_name != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.person_last_name));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.person_age != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.person_age));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.job != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.job));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.marital_status != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.marital_status));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.gender != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.gender));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.weight != null) { //

											strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.weight));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.practice_sport != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.practice_sport));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.smokes != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.smokes));

										} //

										strBuffer_tLogRow_1.append("|");

										if (row6.alcohol != null) { //

											strBuffer_tLogRow_1.append(String.valueOf(row6.alcohol));

										} //

										if (globalMap.get("tLogRow_CONSOLE") != null) {
											consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap
													.get("tLogRow_CONSOLE");
										} else {
											consoleOut_tLogRow_1 = new java.io.PrintStream(
													new java.io.BufferedOutputStream(System.out));
											globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
										}
										consoleOut_tLogRow_1.println(strBuffer_tLogRow_1.toString());
										consoleOut_tLogRow_1.flush();
										nb_line_tLogRow_1++;
//////

//////                    

///////////////////////    			

										tos_count_tLogRow_1++;

										/**
										 * [tLogRow_1 main ] stop
										 */

										/**
										 * [tLogRow_1 process_data_begin ] start
										 */

										currentComponent = "tLogRow_1";

										/**
										 * [tLogRow_1 process_data_begin ] stop
										 */

										/**
										 * [tLogRow_1 process_data_end ] start
										 */

										currentComponent = "tLogRow_1";

										/**
										 * [tLogRow_1 process_data_end ] stop
										 */

										/**
										 * [tFileOutputDelimited_1 process_data_end ] start
										 */

										currentComponent = "tFileOutputDelimited_1";

										/**
										 * [tFileOutputDelimited_1 process_data_end ] stop
										 */

									} // End of branch "ss"

									/**
									 * [tMap_4 process_data_end ] start
									 */

									currentComponent = "tMap_4";

									/**
									 * [tMap_4 process_data_end ] stop
									 */

								} // End of branch "row4"

								/**
								 * [tFilterRow_1 process_data_end ] start
								 */

								currentComponent = "tFilterRow_1";

								/**
								 * [tFilterRow_1 process_data_end ] stop
								 */

								/**
								 * [tUnite_1 process_data_end ] start
								 */

								currentComponent = "tUnite_1";

								/**
								 * [tUnite_1 process_data_end ] stop
								 */

							} // End of branch "OUT1"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_2 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_2 end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

					}
				} finally {
					if (!((Object) ("C:\\Users\\pc\\Desktop\\projet datawarehouse\\fichier_sans_2023.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_2 != null) {
							fid_tFileInputDelimited_2.close();
						}
					}
					if (fid_tFileInputDelimited_2 != null) {
						globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_2", true);
				end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_2 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tMap_2 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				OUT111Struct OUT111_tmp = new OUT111Struct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "net.ucanaccess.jdbc.UcanaccessDriver";
				java.lang.Class.forName(driverClass_tDBInput_1);

				String url_tDBInput_1 = "jdbc:ucanaccess://"
						+ "C://Users//pc//Desktop//projet datawarehouse//Database91.accdb"
						+ ";jackcessOpener=org.talend.ucanaccess.encrypt.CryptCodecOpener;singleConnection=true";
				String dbUser_tDBInput_1 = "";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:Vs7pDduS3fmHV+LhMzAc6OU/cgq01eKbrMi+9Q==");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "select * from Consultations ";

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row2.id = null;
						} else {

							row2.id = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								row2.id = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row2.consultation_date = null;
						} else {

							java.sql.Timestamp timestamp_tDBInput_1 = rs_tDBInput_1.getTimestamp(2);
							if (timestamp_tDBInput_1 != null) {
								row2.consultation_date = new java.util.Date(timestamp_tDBInput_1.getTime());
							} else {
								row2.consultation_date = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row2.price = null;
						} else {

							row2.price = rs_tDBInput_1.getFloat(3);
							if (rs_tDBInput_1.wasNull()) {
								row2.price = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row2.duration = null;
						} else {

							row2.duration = rs_tDBInput_1.getDouble(4);
							if (rs_tDBInput_1.wasNull()) {
								row2.duration = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row2.doctor_first_name = null;
						} else {

							row2.doctor_first_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row2.doctor_last_name = null;
						} else {

							row2.doctor_last_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row2.doctor_age = null;
						} else {

							row2.doctor_age = rs_tDBInput_1.getInt(7);
							if (rs_tDBInput_1.wasNull()) {
								row2.doctor_age = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row2.speciality = null;
						} else {

							row2.speciality = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row2.experience = null;
						} else {

							row2.experience = rs_tDBInput_1.getInt(9);
							if (rs_tDBInput_1.wasNull()) {
								row2.experience = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row2.hospital_name = null;
						} else {

							row2.hospital_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
						}
						if (colQtyInRs_tDBInput_1 < 11) {
							row2.city = null;
						} else {

							row2.city = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11, false);
						}
						if (colQtyInRs_tDBInput_1 < 12) {
							row2.country = null;
						} else {

							row2.country = routines.system.JDBCUtil.getString(rs_tDBInput_1, 12, false);
						}
						if (colQtyInRs_tDBInput_1 < 13) {
							row2.person_first_name = null;
						} else {

							row2.person_first_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 13, false);
						}
						if (colQtyInRs_tDBInput_1 < 14) {
							row2.person_last_name = null;
						} else {

							row2.person_last_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 14, false);
						}
						if (colQtyInRs_tDBInput_1 < 15) {
							row2.person_age = null;
						} else {

							row2.person_age = rs_tDBInput_1.getInt(15);
							if (rs_tDBInput_1.wasNull()) {
								row2.person_age = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 16) {
							row2.job = null;
						} else {

							row2.job = routines.system.JDBCUtil.getString(rs_tDBInput_1, 16, false);
						}
						if (colQtyInRs_tDBInput_1 < 17) {
							row2.marital_status = null;
						} else {

							row2.marital_status = routines.system.JDBCUtil.getString(rs_tDBInput_1, 17, false);
						}
						if (colQtyInRs_tDBInput_1 < 18) {
							row2.gender = null;
						} else {

							row2.gender = routines.system.JDBCUtil.getString(rs_tDBInput_1, 18, false);
						}
						if (colQtyInRs_tDBInput_1 < 19) {
							row2.weight = null;
						} else {

							row2.weight = rs_tDBInput_1.getFloat(19);
							if (rs_tDBInput_1.wasNull()) {
								row2.weight = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 20) {
							row2.practice_sport = null;
						} else {

							row2.practice_sport = routines.system.JDBCUtil.getString(rs_tDBInput_1, 20, false);
						}
						if (colQtyInRs_tDBInput_1 < 21) {
							row2.smokes = null;
						} else {

							row2.smokes = routines.system.JDBCUtil.getString(rs_tDBInput_1, 21, false);
						}
						if (colQtyInRs_tDBInput_1 < 22) {
							row2.alcohol = null;
						} else {

							row2.alcohol = routines.system.JDBCUtil.getString(rs_tDBInput_1, 22, false);
						}

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_2 main ] start
						 */

						currentComponent = "tMap_2";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row2"

							);
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_2 = false;
						boolean mainRowRejected_tMap_2 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
							// ###############################
							// # Output tables

							OUT111 = null;

// # Output table : 'OUT111'
							OUT111_tmp.id = row2.id;
							OUT111_tmp.date = row2.consultation_date;
							OUT111_tmp.price = row2.price;
							OUT111_tmp.duration = row2.duration;
							OUT111_tmp.doctor_first_name = row2.doctor_first_name;
							OUT111_tmp.doctor_last_name = row2.doctor_last_name;
							OUT111_tmp.doctor_age = row2.doctor_age;
							OUT111_tmp.specialty = row2.speciality;
							OUT111_tmp.experience = row2.experience;
							OUT111_tmp.hospital_name = row2.hospital_name;
							OUT111_tmp.city = row2.city;
							OUT111_tmp.country = row2.country;
							OUT111_tmp.person_first_name = row2.person_first_name;
							OUT111_tmp.person_last_name = row2.person_last_name;
							OUT111_tmp.person_age = row2.person_age;
							OUT111_tmp.job = row2.job;
							OUT111_tmp.marital_status = row2.marital_status;
							OUT111_tmp.gender = row2.gender;
							OUT111_tmp.weight = row2.weight;
							OUT111_tmp.practice_sport = row2.practice_sport.equals("1") ? true : false;
							OUT111_tmp.smokes = row2.smokes.equals("1") ? true : false;
							OUT111_tmp.alcohol = row2.alcohol.equals("1") ? true : false;
							OUT111 = OUT111_tmp;
// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_2 = false;

						tos_count_tMap_2++;

						/**
						 * [tMap_2 main ] stop
						 */

						/**
						 * [tMap_2 process_data_begin ] start
						 */

						currentComponent = "tMap_2";

						/**
						 * [tMap_2 process_data_begin ] stop
						 */
// Start of branch "OUT111"
						if (OUT111 != null) {

							/**
							 * [tUnite_1 main ] start
							 */

							currentComponent = "tUnite_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "OUT111"

								);
							}

//////////

// for output
							row3 = new row3Struct();

							row3.id = OUT111.id;
							row3.date = OUT111.date;
							row3.price = OUT111.price;
							row3.duration = OUT111.duration;
							row3.doctor_first_name = OUT111.doctor_first_name;
							row3.doctor_last_name = OUT111.doctor_last_name;
							row3.doctor_age = OUT111.doctor_age;
							row3.specialty = OUT111.specialty;
							row3.experience = OUT111.experience;
							row3.hospital_name = OUT111.hospital_name;
							row3.city = OUT111.city;
							row3.country = OUT111.country;
							row3.person_first_name = OUT111.person_first_name;
							row3.person_last_name = OUT111.person_last_name;
							row3.person_age = OUT111.person_age;
							row3.job = OUT111.job;
							row3.marital_status = OUT111.marital_status;
							row3.gender = OUT111.gender;
							row3.weight = OUT111.weight;
							row3.practice_sport = OUT111.practice_sport;
							row3.smokes = OUT111.smokes;
							row3.alcohol = OUT111.alcohol;

							nb_line_tUnite_1++;

//////////

							tos_count_tUnite_1++;

							/**
							 * [tUnite_1 main ] stop
							 */

							/**
							 * [tUnite_1 process_data_begin ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_begin ] stop
							 */

							/**
							 * [tFilterRow_1 main ] start
							 */

							currentComponent = "tFilterRow_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row3"

								);
							}

							row4 = null;
							Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");
							ope_tFilterRow_1
									.matches(
											(row3.id == null ? false
													: row3.id.compareTo(
															ParserUtils.parseTo_Integer(String.valueOf(0))) != 0),
											"id.compareTo(0) != 0 failed");

							ope_tFilterRow_1
									.matches(
											(row3.duration == null ? false
													: row3.duration.compareTo(
															ParserUtils.parseTo_Double(String.valueOf(0))) != 0),
											"duration.compareTo(0) != 0 failed");

							ope_tFilterRow_1
									.matches(
											(row3.duration == null ? false
													: row3.duration.compareTo(
															ParserUtils.parseTo_Double(String.valueOf(0))) != 0),
											"duration.compareTo(0) != 0 failed");

							ope_tFilterRow_1.matches(
									(row3.doctor_first_name == null ? false
											: row3.doctor_first_name.compareTo("") != 0),
									"doctor_first_name.compareTo(\"\") != 0 failed");
							ope_tFilterRow_1
									.matches(
											((row3.id != null) && (row3.date != null) && (row3.price != null)
													&& (row3.duration != null)
													&& (row3.doctor_first_name != null
															&& !row3.doctor_first_name.isEmpty())),
											"advanced condition failed");

							if (ope_tFilterRow_1.getMatchFlag()) {
								if (row4 == null) {
									row4 = new row4Struct();
								}
								row4.id = row3.id;
								row4.date = row3.date;
								row4.price = row3.price;
								row4.duration = row3.duration;
								row4.doctor_first_name = row3.doctor_first_name;
								row4.doctor_last_name = row3.doctor_last_name;
								row4.doctor_age = row3.doctor_age;
								row4.specialty = row3.specialty;
								row4.experience = row3.experience;
								row4.hospital_name = row3.hospital_name;
								row4.city = row3.city;
								row4.country = row3.country;
								row4.person_first_name = row3.person_first_name;
								row4.person_last_name = row3.person_last_name;
								row4.person_age = row3.person_age;
								row4.job = row3.job;
								row4.marital_status = row3.marital_status;
								row4.gender = row3.gender;
								row4.weight = row3.weight;
								row4.practice_sport = row3.practice_sport;
								row4.smokes = row3.smokes;
								row4.alcohol = row3.alcohol;
								nb_line_ok_tFilterRow_1++;
							} else {
								nb_line_reject_tFilterRow_1++;
							}

							nb_line_tFilterRow_1++;

							tos_count_tFilterRow_1++;

							/**
							 * [tFilterRow_1 main ] stop
							 */

							/**
							 * [tFilterRow_1 process_data_begin ] start
							 */

							currentComponent = "tFilterRow_1";

							/**
							 * [tFilterRow_1 process_data_begin ] stop
							 */
// Start of branch "row4"
							if (row4 != null) {

								/**
								 * [tMap_4 main ] start
								 */

								currentComponent = "tMap_4";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row4"

									);
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_4 = false;
								boolean mainRowRejected_tMap_4 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
									// ###############################
									// # Output tables

									ss = null;

// # Output table : 'ss'
									ss_tmp.id = row3.id;
									ss_tmp.date = row3.date;
									ss_tmp.price = row3.price;
									ss_tmp.duration = row3.duration;
									ss_tmp.doctor_first_name = routine1.capitalizeFirstLetter(row3.doctor_first_name);
									ss_tmp.doctor_last_name = routine1.capitalizeFirstLetter(row3.doctor_last_name);
									ss_tmp.doctor_age = row3.doctor_age;
									ss_tmp.specialty = routine1.capitalizeFirstLetter(row3.specialty);
									ss_tmp.experience = row3.experience;
									ss_tmp.hospital_name = routine1.capitalizeFirstLetter(row3.hospital_name);
									ss_tmp.city = routine1.capitalizeFirstLetter(row3.city);
									ss_tmp.country = routine1.capitalizeFirstLetter(row3.country);
									ss_tmp.person_first_name = routine1.capitalizeFirstLetter(row3.person_first_name);
									ss_tmp.person_last_name = routine1.capitalizeFirstLetter(row3.person_last_name);
									ss_tmp.person_age = row3.person_age;
									ss_tmp.job = routine1.capitalizeFirstLetter(row3.job);
									ss_tmp.marital_status = row3.marital_status;
									ss_tmp.gender = row3.gender;
									ss_tmp.weight = row3.weight;
									ss_tmp.practice_sport = row3.practice_sport;
									ss_tmp.smokes = row3.smokes;
									ss_tmp.alcohol = row3.alcohol;
									ss = ss_tmp;
// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_4 = false;

								tos_count_tMap_4++;

								/**
								 * [tMap_4 main ] stop
								 */

								/**
								 * [tMap_4 process_data_begin ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_begin ] stop
								 */
// Start of branch "ss"
								if (ss != null) {

									/**
									 * [tFileOutputDelimited_1 main ] start
									 */

									currentComponent = "tFileOutputDelimited_1";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "ss"

										);
									}

									StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
									if (ss.id != null) {
										sb_tFileOutputDelimited_1.append(ss.id);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.date != null) {
										sb_tFileOutputDelimited_1
												.append(FormatterUtils.format_Date(ss.date, "yyyy-MM-dd"));
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.price != null) {
										sb_tFileOutputDelimited_1.append(ss.price);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.duration != null) {
										sb_tFileOutputDelimited_1.append(ss.duration);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.doctor_first_name != null) {
										sb_tFileOutputDelimited_1.append(ss.doctor_first_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.doctor_last_name != null) {
										sb_tFileOutputDelimited_1.append(ss.doctor_last_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.doctor_age != null) {
										sb_tFileOutputDelimited_1.append(ss.doctor_age);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.specialty != null) {
										sb_tFileOutputDelimited_1.append(ss.specialty);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.experience != null) {
										sb_tFileOutputDelimited_1.append(ss.experience);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.hospital_name != null) {
										sb_tFileOutputDelimited_1.append(ss.hospital_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.city != null) {
										sb_tFileOutputDelimited_1.append(ss.city);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.country != null) {
										sb_tFileOutputDelimited_1.append(ss.country);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.person_first_name != null) {
										sb_tFileOutputDelimited_1.append(ss.person_first_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.person_last_name != null) {
										sb_tFileOutputDelimited_1.append(ss.person_last_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.person_age != null) {
										sb_tFileOutputDelimited_1.append(ss.person_age);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.job != null) {
										sb_tFileOutputDelimited_1.append(ss.job);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.marital_status != null) {
										sb_tFileOutputDelimited_1.append(ss.marital_status);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.gender != null) {
										sb_tFileOutputDelimited_1.append(ss.gender);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.weight != null) {
										sb_tFileOutputDelimited_1.append(ss.weight);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.practice_sport != null) {
										sb_tFileOutputDelimited_1.append(ss.practice_sport);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.smokes != null) {
										sb_tFileOutputDelimited_1.append(ss.smokes);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.alcohol != null) {
										sb_tFileOutputDelimited_1.append(ss.alcohol);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);

									nb_line_tFileOutputDelimited_1++;
									resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

									outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());

									row6 = ss;

									tos_count_tFileOutputDelimited_1++;

									/**
									 * [tFileOutputDelimited_1 main ] stop
									 */

									/**
									 * [tFileOutputDelimited_1 process_data_begin ] start
									 */

									currentComponent = "tFileOutputDelimited_1";

									/**
									 * [tFileOutputDelimited_1 process_data_begin ] stop
									 */

									/**
									 * [tLogRow_1 main ] start
									 */

									currentComponent = "tLogRow_1";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "row6"

										);
									}

///////////////////////		

									strBuffer_tLogRow_1 = new StringBuilder();

									if (row6.id != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.id));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.date != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.format_Date(row6.date, "yyyy-MM-dd"));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.price != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.price));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.duration != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.duration));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.doctor_first_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_first_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.doctor_last_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_last_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.doctor_age != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_age));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.specialty != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.specialty));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.experience != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.experience));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.hospital_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.hospital_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.city != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.city));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.country != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.country));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.person_first_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.person_first_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.person_last_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.person_last_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.person_age != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.person_age));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.job != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.job));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.marital_status != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.marital_status));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.gender != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.gender));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.weight != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.weight));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.practice_sport != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.practice_sport));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.smokes != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.smokes));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.alcohol != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.alcohol));

									} //

									if (globalMap.get("tLogRow_CONSOLE") != null) {
										consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
									} else {
										consoleOut_tLogRow_1 = new java.io.PrintStream(
												new java.io.BufferedOutputStream(System.out));
										globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
									}
									consoleOut_tLogRow_1.println(strBuffer_tLogRow_1.toString());
									consoleOut_tLogRow_1.flush();
									nb_line_tLogRow_1++;
//////

//////                    

///////////////////////    			

									tos_count_tLogRow_1++;

									/**
									 * [tLogRow_1 main ] stop
									 */

									/**
									 * [tLogRow_1 process_data_begin ] start
									 */

									currentComponent = "tLogRow_1";

									/**
									 * [tLogRow_1 process_data_begin ] stop
									 */

									/**
									 * [tLogRow_1 process_data_end ] start
									 */

									currentComponent = "tLogRow_1";

									/**
									 * [tLogRow_1 process_data_end ] stop
									 */

									/**
									 * [tFileOutputDelimited_1 process_data_end ] start
									 */

									currentComponent = "tFileOutputDelimited_1";

									/**
									 * [tFileOutputDelimited_1 process_data_end ] stop
									 */

								} // End of branch "ss"

								/**
								 * [tMap_4 process_data_end ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_end ] stop
								 */

							} // End of branch "row4"

							/**
							 * [tFilterRow_1 process_data_end ] start
							 */

							currentComponent = "tFilterRow_1";

							/**
							 * [tFilterRow_1 process_data_end ] stop
							 */

							/**
							 * [tUnite_1 process_data_end ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_end ] stop
							 */

						} // End of branch "OUT111"

						/**
						 * [tMap_2 process_data_end ] start
						 */

						currentComponent = "tMap_2";

						/**
						 * [tMap_2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}
				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tMap_3 begin ] start
				 */

				ok_Hash.put("tMap_3", false);
				start_Hash.put("tMap_3", System.currentTimeMillis());

				currentComponent = "tMap_3";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row5");
				}

				int tos_count_tMap_3 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_3__Struct {
				}
				Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				kkkStruct kkk_tmp = new kkkStruct();
// ###############################

				/**
				 * [tMap_3 begin ] stop
				 */

				/**
				 * [tFileInputJSON_1 begin ] start
				 */

				ok_Hash.put("tFileInputJSON_1", false);
				start_Hash.put("tFileInputJSON_1", System.currentTimeMillis());

				currentComponent = "tFileInputJSON_1";

				int tos_count_tFileInputJSON_1 = 0;

				class JsonPathCache_tFileInputJSON_1 {
					final java.util.Map<String, com.jayway.jsonpath.JsonPath> jsonPathString2compiledJsonPath = new java.util.HashMap<String, com.jayway.jsonpath.JsonPath>();

					public com.jayway.jsonpath.JsonPath getCompiledJsonPath(String jsonPath) {
						if (jsonPathString2compiledJsonPath.containsKey(jsonPath)) {
							return jsonPathString2compiledJsonPath.get(jsonPath);
						} else {
							com.jayway.jsonpath.JsonPath compiledLoopPath = com.jayway.jsonpath.JsonPath
									.compile(jsonPath);
							jsonPathString2compiledJsonPath.put(jsonPath, compiledLoopPath);
							return compiledLoopPath;
						}
					}
				}

				int nb_line_tFileInputJSON_1 = 0;

				JsonPathCache_tFileInputJSON_1 jsonPathCache_tFileInputJSON_1 = new JsonPathCache_tFileInputJSON_1();

				String loopPath_tFileInputJSON_1 = "$[*]";
				java.util.List<Object> resultset_tFileInputJSON_1 = new java.util.ArrayList<Object>();

				java.io.InputStream is_tFileInputJSON_1 = null;
				com.jayway.jsonpath.ParseContext parseContext_tFileInputJSON_1 = com.jayway.jsonpath.JsonPath
						.using(com.jayway.jsonpath.Configuration.defaultConfiguration());
				Object filenameOrStream_tFileInputJSON_1 = null;
				try {
					filenameOrStream_tFileInputJSON_1 = "C:\\Users\\pc\\Desktop\\projet datawarehouse\\fichier_filtre_2023.json";
				} catch (java.lang.Exception e_tFileInputJSON_1) {
					globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());

					globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
					System.err.println(e_tFileInputJSON_1.getMessage());
				}

				com.jayway.jsonpath.ReadContext document_tFileInputJSON_1 = null;
				try {
					if (filenameOrStream_tFileInputJSON_1 instanceof java.io.InputStream) {
						is_tFileInputJSON_1 = (java.io.InputStream) filenameOrStream_tFileInputJSON_1;
					} else {

						is_tFileInputJSON_1 = new java.io.FileInputStream((String) filenameOrStream_tFileInputJSON_1);

					}

					document_tFileInputJSON_1 = parseContext_tFileInputJSON_1.parse(is_tFileInputJSON_1, "UTF-8");
					com.jayway.jsonpath.JsonPath compiledLoopPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
							.getCompiledJsonPath(loopPath_tFileInputJSON_1);
					Object result_tFileInputJSON_1 = document_tFileInputJSON_1.read(compiledLoopPath_tFileInputJSON_1,
							net.minidev.json.JSONObject.class);
					if (result_tFileInputJSON_1 instanceof net.minidev.json.JSONArray) {
						resultset_tFileInputJSON_1 = (net.minidev.json.JSONArray) result_tFileInputJSON_1;
					} else {
						resultset_tFileInputJSON_1.add(result_tFileInputJSON_1);
					}
				} catch (java.lang.Exception e_tFileInputJSON_1) {
					globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
					globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
					System.err.println(e_tFileInputJSON_1.getMessage());
				} finally {
					if (is_tFileInputJSON_1 != null) {
						is_tFileInputJSON_1.close();
					}
				}

				String jsonPath_tFileInputJSON_1 = null;
				com.jayway.jsonpath.JsonPath compiledJsonPath_tFileInputJSON_1 = null;

				Object value_tFileInputJSON_1 = null;
				Object root_tFileInputJSON_1 = null;
				for (Object row_tFileInputJSON_1 : resultset_tFileInputJSON_1) {
					nb_line_tFileInputJSON_1++;
					row5 = null;
					boolean whetherReject_tFileInputJSON_1 = false;
					row5 = new row5Struct();

					try {
						jsonPath_tFileInputJSON_1 = "id";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.id = ParserUtils.parseTo_Integer(value_tFileInputJSON_1.toString());
							} else {
								row5.id =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.id =

									null;
						}
						jsonPath_tFileInputJSON_1 = "date";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.date = ParserUtils.parseTo_Date(value_tFileInputJSON_1.toString(), "yyyy-MM-dd");
							} else {
								row5.date =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.date =

									null;
						}
						jsonPath_tFileInputJSON_1 = "price";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.price = ParserUtils.parseTo_Float(value_tFileInputJSON_1.toString());
							} else {
								row5.price =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.price =

									null;
						}
						jsonPath_tFileInputJSON_1 = "duration";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.duration = ParserUtils.parseTo_Double(value_tFileInputJSON_1.toString());
							} else {
								row5.duration =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.duration =

									null;
						}
						jsonPath_tFileInputJSON_1 = "doctor_first_name";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.doctor_first_name = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.doctor_first_name =

									null;
						}
						jsonPath_tFileInputJSON_1 = "doctor_last_name";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.doctor_last_name = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.doctor_last_name =

									null;
						}
						jsonPath_tFileInputJSON_1 = "doctor_age";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.doctor_age = ParserUtils.parseTo_Integer(value_tFileInputJSON_1.toString());
							} else {
								row5.doctor_age =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.doctor_age =

									null;
						}
						jsonPath_tFileInputJSON_1 = "speciality";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.specialty = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.specialty =

									null;
						}
						jsonPath_tFileInputJSON_1 = "experience";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.experience = ParserUtils.parseTo_Integer(value_tFileInputJSON_1.toString());
							} else {
								row5.experience =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.experience =

									null;
						}
						jsonPath_tFileInputJSON_1 = "hospital_name";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.hospital_name = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.hospital_name =

									null;
						}
						jsonPath_tFileInputJSON_1 = "city";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.city = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.city =

									null;
						}
						jsonPath_tFileInputJSON_1 = "country";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.country = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.country =

									null;
						}
						jsonPath_tFileInputJSON_1 = "person_first_name";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.person_first_name = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.person_first_name =

									null;
						}
						jsonPath_tFileInputJSON_1 = "person_last_name";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.person_last_name = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.person_last_name =

									null;
						}
						jsonPath_tFileInputJSON_1 = "person_age";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.person_age = ParserUtils.parseTo_Integer(value_tFileInputJSON_1.toString());
							} else {
								row5.person_age =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.person_age =

									null;
						}
						jsonPath_tFileInputJSON_1 = "job";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.job = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.job =

									null;
						}
						jsonPath_tFileInputJSON_1 = "marital_status";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.marital_status = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.marital_status =

									null;
						}
						jsonPath_tFileInputJSON_1 = "gender";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							row5.gender = value_tFileInputJSON_1 == null ?

									null : value_tFileInputJSON_1.toString();
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.gender =

									null;
						}
						jsonPath_tFileInputJSON_1 = "weight";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.weight = ParserUtils.parseTo_Float(value_tFileInputJSON_1.toString());
							} else {
								row5.weight =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.weight =

									null;
						}
						jsonPath_tFileInputJSON_1 = "practice_sport";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.practice_sport = ParserUtils.parseTo_Boolean(value_tFileInputJSON_1.toString());
							} else {
								row5.practice_sport =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.practice_sport =

									null;
						}
						jsonPath_tFileInputJSON_1 = "smokes";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.smokes = ParserUtils.parseTo_Boolean(value_tFileInputJSON_1.toString());
							} else {
								row5.smokes =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.smokes =

									null;
						}
						jsonPath_tFileInputJSON_1 = "alcohol";
						compiledJsonPath_tFileInputJSON_1 = jsonPathCache_tFileInputJSON_1
								.getCompiledJsonPath(jsonPath_tFileInputJSON_1);

						try {

							value_tFileInputJSON_1 = compiledJsonPath_tFileInputJSON_1.read(row_tFileInputJSON_1);

							if (value_tFileInputJSON_1 != null && !value_tFileInputJSON_1.toString().isEmpty()) {
								row5.alcohol = ParserUtils.parseTo_Boolean(value_tFileInputJSON_1.toString());
							} else {
								row5.alcohol =

										null;
							}
						} catch (com.jayway.jsonpath.PathNotFoundException e_tFileInputJSON_1) {
							globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
							row5.alcohol =

									null;
						}
					} catch (java.lang.Exception e_tFileInputJSON_1) {
						globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
						whetherReject_tFileInputJSON_1 = true;
						System.err.println(e_tFileInputJSON_1.getMessage());
						row5 = null;
						globalMap.put("tFileInputJSON_1_ERROR_MESSAGE", e_tFileInputJSON_1.getMessage());
					}
//}

					/**
					 * [tFileInputJSON_1 begin ] stop
					 */

					/**
					 * [tFileInputJSON_1 main ] start
					 */

					currentComponent = "tFileInputJSON_1";

					tos_count_tFileInputJSON_1++;

					/**
					 * [tFileInputJSON_1 main ] stop
					 */

					/**
					 * [tFileInputJSON_1 process_data_begin ] start
					 */

					currentComponent = "tFileInputJSON_1";

					/**
					 * [tFileInputJSON_1 process_data_begin ] stop
					 */
// Start of branch "row5"
					if (row5 != null) {

						/**
						 * [tMap_3 main ] start
						 */

						currentComponent = "tMap_3";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row5"

							);
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;

						// ###############################
						// # Input tables (lookups)
						boolean rejectedInnerJoin_tMap_3 = false;
						boolean mainRowRejected_tMap_3 = false;

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
							// ###############################
							// # Output tables

							kkk = null;

// # Output table : 'kkk'
							kkk_tmp.id = row5.id;
							kkk_tmp.date = row5.date;
							kkk_tmp.price = row5.price;
							kkk_tmp.duration = row5.duration;
							kkk_tmp.doctor_first_name = row5.doctor_first_name;
							kkk_tmp.doctor_last_name = row5.doctor_last_name;
							kkk_tmp.doctor_age = row5.doctor_age;
							kkk_tmp.specialty = row5.specialty;
							kkk_tmp.experience = row5.experience;
							kkk_tmp.hospital_name = row5.hospital_name;
							kkk_tmp.city = routine1.replaceWithFullName(row5.city);
							kkk_tmp.country = routine1.replaceWithFullName(row5.country);
							kkk_tmp.person_first_name = row5.person_first_name;
							kkk_tmp.person_last_name = row5.person_last_name;
							kkk_tmp.person_age = row5.person_age;
							kkk_tmp.job = row5.job;
							kkk_tmp.marital_status = row5.marital_status;
							kkk_tmp.gender = row5.gender;
							kkk_tmp.weight = row5.weight;
							kkk_tmp.practice_sport = row5.practice_sport;
							kkk_tmp.smokes = row5.smokes;
							kkk_tmp.alcohol = row5.alcohol;
							kkk = kkk_tmp;
// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_3 = false;

						tos_count_tMap_3++;

						/**
						 * [tMap_3 main ] stop
						 */

						/**
						 * [tMap_3 process_data_begin ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_begin ] stop
						 */
// Start of branch "kkk"
						if (kkk != null) {

							/**
							 * [tUnite_1 main ] start
							 */

							currentComponent = "tUnite_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "kkk"

								);
							}

//////////

// for output
							row3 = new row3Struct();

							row3.id = kkk.id;
							row3.date = kkk.date;
							row3.price = kkk.price;
							row3.duration = kkk.duration;
							row3.doctor_first_name = kkk.doctor_first_name;
							row3.doctor_last_name = kkk.doctor_last_name;
							row3.doctor_age = kkk.doctor_age;
							row3.specialty = kkk.specialty;
							row3.experience = kkk.experience;
							row3.hospital_name = kkk.hospital_name;
							row3.city = kkk.city;
							row3.country = kkk.country;
							row3.person_first_name = kkk.person_first_name;
							row3.person_last_name = kkk.person_last_name;
							row3.person_age = kkk.person_age;
							row3.job = kkk.job;
							row3.marital_status = kkk.marital_status;
							row3.gender = kkk.gender;
							row3.weight = kkk.weight;
							row3.practice_sport = kkk.practice_sport;
							row3.smokes = kkk.smokes;
							row3.alcohol = kkk.alcohol;

							nb_line_tUnite_1++;

//////////

							tos_count_tUnite_1++;

							/**
							 * [tUnite_1 main ] stop
							 */

							/**
							 * [tUnite_1 process_data_begin ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_begin ] stop
							 */

							/**
							 * [tFilterRow_1 main ] start
							 */

							currentComponent = "tFilterRow_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row3"

								);
							}

							row4 = null;
							Operator_tFilterRow_1 ope_tFilterRow_1 = new Operator_tFilterRow_1("&&");
							ope_tFilterRow_1
									.matches(
											(row3.id == null ? false
													: row3.id.compareTo(
															ParserUtils.parseTo_Integer(String.valueOf(0))) != 0),
											"id.compareTo(0) != 0 failed");

							ope_tFilterRow_1
									.matches(
											(row3.duration == null ? false
													: row3.duration.compareTo(
															ParserUtils.parseTo_Double(String.valueOf(0))) != 0),
											"duration.compareTo(0) != 0 failed");

							ope_tFilterRow_1
									.matches(
											(row3.duration == null ? false
													: row3.duration.compareTo(
															ParserUtils.parseTo_Double(String.valueOf(0))) != 0),
											"duration.compareTo(0) != 0 failed");

							ope_tFilterRow_1.matches(
									(row3.doctor_first_name == null ? false
											: row3.doctor_first_name.compareTo("") != 0),
									"doctor_first_name.compareTo(\"\") != 0 failed");
							ope_tFilterRow_1
									.matches(
											((row3.id != null) && (row3.date != null) && (row3.price != null)
													&& (row3.duration != null)
													&& (row3.doctor_first_name != null
															&& !row3.doctor_first_name.isEmpty())),
											"advanced condition failed");

							if (ope_tFilterRow_1.getMatchFlag()) {
								if (row4 == null) {
									row4 = new row4Struct();
								}
								row4.id = row3.id;
								row4.date = row3.date;
								row4.price = row3.price;
								row4.duration = row3.duration;
								row4.doctor_first_name = row3.doctor_first_name;
								row4.doctor_last_name = row3.doctor_last_name;
								row4.doctor_age = row3.doctor_age;
								row4.specialty = row3.specialty;
								row4.experience = row3.experience;
								row4.hospital_name = row3.hospital_name;
								row4.city = row3.city;
								row4.country = row3.country;
								row4.person_first_name = row3.person_first_name;
								row4.person_last_name = row3.person_last_name;
								row4.person_age = row3.person_age;
								row4.job = row3.job;
								row4.marital_status = row3.marital_status;
								row4.gender = row3.gender;
								row4.weight = row3.weight;
								row4.practice_sport = row3.practice_sport;
								row4.smokes = row3.smokes;
								row4.alcohol = row3.alcohol;
								nb_line_ok_tFilterRow_1++;
							} else {
								nb_line_reject_tFilterRow_1++;
							}

							nb_line_tFilterRow_1++;

							tos_count_tFilterRow_1++;

							/**
							 * [tFilterRow_1 main ] stop
							 */

							/**
							 * [tFilterRow_1 process_data_begin ] start
							 */

							currentComponent = "tFilterRow_1";

							/**
							 * [tFilterRow_1 process_data_begin ] stop
							 */
// Start of branch "row4"
							if (row4 != null) {

								/**
								 * [tMap_4 main ] start
								 */

								currentComponent = "tMap_4";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row4"

									);
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_4 = false;
								boolean mainRowRejected_tMap_4 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
									// ###############################
									// # Output tables

									ss = null;

// # Output table : 'ss'
									ss_tmp.id = row3.id;
									ss_tmp.date = row3.date;
									ss_tmp.price = row3.price;
									ss_tmp.duration = row3.duration;
									ss_tmp.doctor_first_name = routine1.capitalizeFirstLetter(row3.doctor_first_name);
									ss_tmp.doctor_last_name = routine1.capitalizeFirstLetter(row3.doctor_last_name);
									ss_tmp.doctor_age = row3.doctor_age;
									ss_tmp.specialty = routine1.capitalizeFirstLetter(row3.specialty);
									ss_tmp.experience = row3.experience;
									ss_tmp.hospital_name = routine1.capitalizeFirstLetter(row3.hospital_name);
									ss_tmp.city = routine1.capitalizeFirstLetter(row3.city);
									ss_tmp.country = routine1.capitalizeFirstLetter(row3.country);
									ss_tmp.person_first_name = routine1.capitalizeFirstLetter(row3.person_first_name);
									ss_tmp.person_last_name = routine1.capitalizeFirstLetter(row3.person_last_name);
									ss_tmp.person_age = row3.person_age;
									ss_tmp.job = routine1.capitalizeFirstLetter(row3.job);
									ss_tmp.marital_status = row3.marital_status;
									ss_tmp.gender = row3.gender;
									ss_tmp.weight = row3.weight;
									ss_tmp.practice_sport = row3.practice_sport;
									ss_tmp.smokes = row3.smokes;
									ss_tmp.alcohol = row3.alcohol;
									ss = ss_tmp;
// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_4 = false;

								tos_count_tMap_4++;

								/**
								 * [tMap_4 main ] stop
								 */

								/**
								 * [tMap_4 process_data_begin ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_begin ] stop
								 */
// Start of branch "ss"
								if (ss != null) {

									/**
									 * [tFileOutputDelimited_1 main ] start
									 */

									currentComponent = "tFileOutputDelimited_1";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "ss"

										);
									}

									StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
									if (ss.id != null) {
										sb_tFileOutputDelimited_1.append(ss.id);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.date != null) {
										sb_tFileOutputDelimited_1
												.append(FormatterUtils.format_Date(ss.date, "yyyy-MM-dd"));
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.price != null) {
										sb_tFileOutputDelimited_1.append(ss.price);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.duration != null) {
										sb_tFileOutputDelimited_1.append(ss.duration);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.doctor_first_name != null) {
										sb_tFileOutputDelimited_1.append(ss.doctor_first_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.doctor_last_name != null) {
										sb_tFileOutputDelimited_1.append(ss.doctor_last_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.doctor_age != null) {
										sb_tFileOutputDelimited_1.append(ss.doctor_age);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.specialty != null) {
										sb_tFileOutputDelimited_1.append(ss.specialty);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.experience != null) {
										sb_tFileOutputDelimited_1.append(ss.experience);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.hospital_name != null) {
										sb_tFileOutputDelimited_1.append(ss.hospital_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.city != null) {
										sb_tFileOutputDelimited_1.append(ss.city);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.country != null) {
										sb_tFileOutputDelimited_1.append(ss.country);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.person_first_name != null) {
										sb_tFileOutputDelimited_1.append(ss.person_first_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.person_last_name != null) {
										sb_tFileOutputDelimited_1.append(ss.person_last_name);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.person_age != null) {
										sb_tFileOutputDelimited_1.append(ss.person_age);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.job != null) {
										sb_tFileOutputDelimited_1.append(ss.job);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.marital_status != null) {
										sb_tFileOutputDelimited_1.append(ss.marital_status);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.gender != null) {
										sb_tFileOutputDelimited_1.append(ss.gender);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.weight != null) {
										sb_tFileOutputDelimited_1.append(ss.weight);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.practice_sport != null) {
										sb_tFileOutputDelimited_1.append(ss.practice_sport);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.smokes != null) {
										sb_tFileOutputDelimited_1.append(ss.smokes);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
									if (ss.alcohol != null) {
										sb_tFileOutputDelimited_1.append(ss.alcohol);
									}
									sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);

									nb_line_tFileOutputDelimited_1++;
									resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

									outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());

									row6 = ss;

									tos_count_tFileOutputDelimited_1++;

									/**
									 * [tFileOutputDelimited_1 main ] stop
									 */

									/**
									 * [tFileOutputDelimited_1 process_data_begin ] start
									 */

									currentComponent = "tFileOutputDelimited_1";

									/**
									 * [tFileOutputDelimited_1 process_data_begin ] stop
									 */

									/**
									 * [tLogRow_1 main ] start
									 */

									currentComponent = "tLogRow_1";

									if (execStat) {
										runStat.updateStatOnConnection(iterateId, 1, 1

												, "row6"

										);
									}

///////////////////////		

									strBuffer_tLogRow_1 = new StringBuilder();

									if (row6.id != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.id));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.date != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.format_Date(row6.date, "yyyy-MM-dd"));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.price != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.price));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.duration != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.duration));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.doctor_first_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_first_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.doctor_last_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_last_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.doctor_age != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.doctor_age));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.specialty != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.specialty));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.experience != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.experience));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.hospital_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.hospital_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.city != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.city));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.country != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.country));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.person_first_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.person_first_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.person_last_name != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.person_last_name));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.person_age != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.person_age));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.job != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.job));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.marital_status != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.marital_status));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.gender != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.gender));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.weight != null) { //

										strBuffer_tLogRow_1.append(FormatterUtils.formatUnwithE(row6.weight));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.practice_sport != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.practice_sport));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.smokes != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.smokes));

									} //

									strBuffer_tLogRow_1.append("|");

									if (row6.alcohol != null) { //

										strBuffer_tLogRow_1.append(String.valueOf(row6.alcohol));

									} //

									if (globalMap.get("tLogRow_CONSOLE") != null) {
										consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
									} else {
										consoleOut_tLogRow_1 = new java.io.PrintStream(
												new java.io.BufferedOutputStream(System.out));
										globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
									}
									consoleOut_tLogRow_1.println(strBuffer_tLogRow_1.toString());
									consoleOut_tLogRow_1.flush();
									nb_line_tLogRow_1++;
//////

//////                    

///////////////////////    			

									tos_count_tLogRow_1++;

									/**
									 * [tLogRow_1 main ] stop
									 */

									/**
									 * [tLogRow_1 process_data_begin ] start
									 */

									currentComponent = "tLogRow_1";

									/**
									 * [tLogRow_1 process_data_begin ] stop
									 */

									/**
									 * [tLogRow_1 process_data_end ] start
									 */

									currentComponent = "tLogRow_1";

									/**
									 * [tLogRow_1 process_data_end ] stop
									 */

									/**
									 * [tFileOutputDelimited_1 process_data_end ] start
									 */

									currentComponent = "tFileOutputDelimited_1";

									/**
									 * [tFileOutputDelimited_1 process_data_end ] stop
									 */

								} // End of branch "ss"

								/**
								 * [tMap_4 process_data_end ] start
								 */

								currentComponent = "tMap_4";

								/**
								 * [tMap_4 process_data_end ] stop
								 */

							} // End of branch "row4"

							/**
							 * [tFilterRow_1 process_data_end ] start
							 */

							currentComponent = "tFilterRow_1";

							/**
							 * [tFilterRow_1 process_data_end ] stop
							 */

							/**
							 * [tUnite_1 process_data_end ] start
							 */

							currentComponent = "tUnite_1";

							/**
							 * [tUnite_1 process_data_end ] stop
							 */

						} // End of branch "kkk"

						/**
						 * [tMap_3 process_data_end ] start
						 */

						currentComponent = "tMap_3";

						/**
						 * [tMap_3 process_data_end ] stop
						 */

					} // End of branch "row5"

					/**
					 * [tFileInputJSON_1 process_data_end ] start
					 */

					currentComponent = "tFileInputJSON_1";

					/**
					 * [tFileInputJSON_1 process_data_end ] stop
					 */

					/**
					 * [tFileInputJSON_1 end ] start
					 */

					currentComponent = "tFileInputJSON_1";

				}
				globalMap.put("tFileInputJSON_1_NB_LINE", nb_line_tFileInputJSON_1);

				ok_Hash.put("tFileInputJSON_1", true);
				end_Hash.put("tFileInputJSON_1", System.currentTimeMillis());

				/**
				 * [tFileInputJSON_1 end ] stop
				 */

				/**
				 * [tMap_3 end ] start
				 */

				currentComponent = "tMap_3";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row5");
				}

				ok_Hash.put("tMap_3", true);
				end_Hash.put("tMap_3", System.currentTimeMillis());

				/**
				 * [tMap_3 end ] stop
				 */

				/**
				 * [tUnite_1 end ] start
				 */

				currentComponent = "tUnite_1";

				globalMap.put("tUnite_1_NB_LINE", nb_line_tUnite_1);
				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "OUT1", "OUT111", "kkk");
				}

				ok_Hash.put("tUnite_1", true);
				end_Hash.put("tUnite_1", System.currentTimeMillis());

				/**
				 * [tUnite_1 end ] stop
				 */

				/**
				 * [tFilterRow_1 end ] start
				 */

				currentComponent = "tFilterRow_1";

				globalMap.put("tFilterRow_1_NB_LINE", nb_line_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_OK", nb_line_ok_tFilterRow_1);
				globalMap.put("tFilterRow_1_NB_LINE_REJECT", nb_line_reject_tFilterRow_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				ok_Hash.put("tFilterRow_1", true);
				end_Hash.put("tFilterRow_1", System.currentTimeMillis());

				/**
				 * [tFilterRow_1 end ] stop
				 */

				/**
				 * [tMap_4 end ] start
				 */

				currentComponent = "tMap_4";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row4");
				}

				ok_Hash.put("tMap_4", true);
				end_Hash.put("tMap_4", System.currentTimeMillis());

				/**
				 * [tMap_4 end ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 end ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (outtFileOutputDelimited_1 != null) {
					outtFileOutputDelimited_1.flush();
					outtFileOutputDelimited_1.close();
				}

				globalMap.put("tFileOutputDelimited_1_NB_LINE", nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);

				resourceMap.put("finish_tFileOutputDelimited_1", true);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "ss");
				}

				ok_Hash.put("tFileOutputDelimited_1", true);
				end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileOutputDelimited_1 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

//////
//////
				globalMap.put("tLogRow_1_NB_LINE", nb_line_tLogRow_1);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row6");
				}

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_2 finally ] start
				 */

				currentComponent = "tFileInputDelimited_2";

				/**
				 * [tFileInputDelimited_2 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tFileInputJSON_1 finally ] start
				 */

				currentComponent = "tFileInputJSON_1";

				/**
				 * [tFileInputJSON_1 finally ] stop
				 */

				/**
				 * [tMap_3 finally ] start
				 */

				currentComponent = "tMap_3";

				/**
				 * [tMap_3 finally ] stop
				 */

				/**
				 * [tUnite_1 finally ] start
				 */

				currentComponent = "tUnite_1";

				/**
				 * [tUnite_1 finally ] stop
				 */

				/**
				 * [tFilterRow_1 finally ] start
				 */

				currentComponent = "tFilterRow_1";

				/**
				 * [tFilterRow_1 finally ] stop
				 */

				/**
				 * [tMap_4 finally ] start
				 */

				currentComponent = "tMap_4";

				/**
				 * [tMap_4 finally ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (resourceMap.get("finish_tFileOutputDelimited_1") == null) {

					java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer) resourceMap
							.get("out_tFileOutputDelimited_1");
					if (outtFileOutputDelimited_1 != null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}

				}

				/**
				 * [tFileOutputDelimited_1 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				/**
				 * [tLogRow_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final job2 job2Class = new job2();

		int exitCode = job2Class.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = job2.class.getClassLoader()
					.getResourceAsStream("projet_data/job2_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = job2.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_2) {
			globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_2.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : job2");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 374389 characters generated by Talend Open Studio for Data Integration on the
 * 8 décembre 2024, 18:02:31 WAT
 ************************************************************************************************/