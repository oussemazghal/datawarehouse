// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package projet_data.jobconsultation2_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: jobconsultation2 Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class jobconsultation2 implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "jobconsultation2";
	private final String projectName = "PROJET_DATA";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					jobconsultation2.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(jobconsultation2.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJoin_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tJoin_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHash_row4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tHash_row2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_jobconsultation2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_jobconsultation2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public Integer iddoctor;

		public Integer getIddoctor() {
			return this.iddoctor;
		}

		public Integer idpatient;

		public Integer getIdpatient() {
			return this.idpatient;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row5Struct other = (row5Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row5Struct other) {

			other.id = this.id;
			other.iddoctor = this.iddoctor;
			other.idpatient = this.idpatient;

		}

		public void copyKeysDataTo(row5Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.idpatient = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.idpatient = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// Integer

				writeInteger(this.idpatient, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// Integer

				writeInteger(this.idpatient, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",iddoctor=" + String.valueOf(iddoctor));
			sb.append(",idpatient=" + String.valueOf(idpatient));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row5Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_jobconsultation2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_jobconsultation2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public Integer iddoctor;

		public Integer getIddoctor() {
			return this.iddoctor;
		}

		public Integer idpatient;

		public Integer getIdpatient() {
			return this.idpatient;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row3Struct other = (row3Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row3Struct other) {

			other.id = this.id;
			other.iddoctor = this.iddoctor;
			other.idpatient = this.idpatient;

		}

		public void copyKeysDataTo(row3Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.idpatient = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.idpatient = readInteger(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// Integer

				writeInteger(this.idpatient, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// Integer

				writeInteger(this.idpatient, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",iddoctor=" + String.valueOf(iddoctor));
			sb.append(",idpatient=" + String.valueOf(idpatient));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_jobconsultation2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_jobconsultation2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public Integer iddoctor;

		public Integer getIddoctor() {
			return this.iddoctor;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row1Struct other = (row1Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(row1Struct other) {

			other.id = this.id;
			other.iddoctor = this.iddoctor;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;

		}

		public void copyKeysDataTo(row1Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",iddoctor=" + String.valueOf(iddoctor));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tDBInput_2Struct implements routines.system.IPersistableRow<after_tDBInput_2Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_jobconsultation2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_jobconsultation2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public Integer iddoctor;

		public Integer getIddoctor() {
			return this.iddoctor;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final after_tDBInput_2Struct other = (after_tDBInput_2Struct) obj;

			if (this.id == null) {
				if (other.id != null)
					return false;

			} else if (!this.id.equals(other.id))

				return false;

			return true;
		}

		public void copyDataTo(after_tDBInput_2Struct other) {

			other.id = this.id;
			other.iddoctor = this.iddoctor;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;

		}

		public void copyKeysDataTo(after_tDBInput_2Struct other) {

			other.id = this.id;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.id = readInteger(dis);

					this.iddoctor = readInteger(dis);

					this.date = readDate(dis);

					length = dis.readByte();
					if (length == -1) {
						this.price = null;
					} else {
						this.price = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readDouble();
					}

					this.hospital_name = readString(dis);

					this.city = readString(dis);

					this.country = readString(dis);

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.job = readString(dis);

					this.marital_status = readString(dis);

					this.gender = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.id, dos);

				// Integer

				writeInteger(this.iddoctor, dos);

				// java.util.Date

				writeDate(this.date, dos);

				// Float

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				// Double

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				// String

				writeString(this.hospital_name, dos);

				// String

				writeString(this.city, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// String

				writeString(this.job, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.gender, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",iddoctor=" + String.valueOf(iddoctor));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tDBInput_2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.id, other.id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tDBInput_1Process(globalMap);
				tFileInputDelimited_1Process(globalMap);

				row1Struct row1 = new row1Struct();
				row3Struct row3 = new row3Struct();
				row5Struct row5 = new row5Struct();

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row5");
				}

				int tos_count_tLogRow_1 = 0;

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_1 = "|";
				java.io.PrintStream consoleOut_tLogRow_1 = null;

				StringBuilder strBuffer_tLogRow_1 = null;
				int nb_line_tLogRow_1 = 0;
///////////////////////    			

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tJoin_2 begin ] start
				 */

				ok_Hash.put("tJoin_2", false);
				start_Hash.put("tJoin_2", System.currentTimeMillis());

				currentComponent = "tJoin_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row3");
				}

				int tos_count_tJoin_2 = 0;

				final java.util.Map<row4Struct, row4Struct> tHash_tJoin_2 = (java.util.Map<row4Struct, row4Struct>) globalMap
						.get("tHash_row4");

				class Util_tJoin_2 {
					row4Struct lookupValue = null;
					row4Struct row4HashKey = new row4Struct();

					public boolean isJoined(row3Struct mainRow) {
						row4HashKey.person_first_name = mainRow.person_first_name;

						row4HashKey.person_last_name = mainRow.person_last_name;

						row4HashKey.job = mainRow.job;

						row4HashKey.marital_status = mainRow.marital_status;

						row4HashKey.gender = mainRow.gender;

						row4HashKey.hashCodeDirty = true;
						lookupValue = tHash_tJoin_2.get(row4HashKey);
						if (lookupValue != null) {
							return true;
						} else {
						}
						return false;
					}
				}

				Util_tJoin_2 util_tJoin_2 = new Util_tJoin_2();

				int nb_line_tJoin_2 = 0;

				/**
				 * [tJoin_2 begin ] stop
				 */

				/**
				 * [tJoin_1 begin ] start
				 */

				ok_Hash.put("tJoin_1", false);
				start_Hash.put("tJoin_1", System.currentTimeMillis());

				currentComponent = "tJoin_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tJoin_1 = 0;

				final java.util.Map<row2Struct, row2Struct> tHash_tJoin_1 = (java.util.Map<row2Struct, row2Struct>) globalMap
						.get("tHash_row2");

				class Util_tJoin_1 {
					row2Struct lookupValue = null;
					row2Struct row2HashKey = new row2Struct();

					public boolean isJoined(row1Struct mainRow) {
						row2HashKey.doctor_first_name = mainRow.id;

						row2HashKey.doctor_last_name = mainRow.id;

						row2HashKey.hashCodeDirty = true;
						lookupValue = tHash_tJoin_1.get(row2HashKey);
						if (lookupValue != null) {
							return true;
						} else {
						}
						return false;
					}
				}

				Util_tJoin_1 util_tJoin_1 = new Util_tJoin_1();

				int nb_line_tJoin_1 = 0;

				/**
				 * [tJoin_1 begin ] stop
				 */

				/**
				 * [tDBInput_2 begin ] start
				 */

				ok_Hash.put("tDBInput_2", false);
				start_Hash.put("tDBInput_2", System.currentTimeMillis());

				currentComponent = "tDBInput_2";

				int tos_count_tDBInput_2 = 0;

				java.util.Calendar calendar_tDBInput_2 = java.util.Calendar.getInstance();
				calendar_tDBInput_2.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_2 = calendar_tDBInput_2.getTime();
				int nb_line_tDBInput_2 = 0;
				java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
				String dbUser_tDBInput_2 = "root";

				final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:Jg8Di/7Fyi8F6smrRqmkDM2uQAXm9RyMsjVhgA==");

				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;

				String properties_tDBInput_2 = "noDatetimeStringSync=true";
				if (properties_tDBInput_2 == null || properties_tDBInput_2.trim().length() == 0) {
					properties_tDBInput_2 = "";
				}
				String url_tDBInput_2 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "datawarehouse" + "?"
						+ properties_tDBInput_2;

				conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2, dbUser_tDBInput_2,
						dbPwd_tDBInput_2);

				java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

				String dbquery_tDBInput_2 = "select * from doctordimension";

				globalMap.put("tDBInput_2_QUERY", dbquery_tDBInput_2);
				java.sql.ResultSet rs_tDBInput_2 = null;

				try {
					rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
					java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
					int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

					String tmpContent_tDBInput_2 = null;

					while (rs_tDBInput_2.next()) {
						nb_line_tDBInput_2++;

						if (colQtyInRs_tDBInput_2 < 1) {
							row1.id = null;
						} else {

							row1.id = rs_tDBInput_2.getInt(1);
							if (rs_tDBInput_2.wasNull()) {
								row1.id = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 2) {
							row1.iddoctor = null;
						} else {

							row1.iddoctor = rs_tDBInput_2.getInt(2);
							if (rs_tDBInput_2.wasNull()) {
								row1.iddoctor = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 3) {
							row1.date = null;
						} else {

							if (rs_tDBInput_2.getString(3) != null) {
								String dateString_tDBInput_2 = rs_tDBInput_2.getString(3);
								if (!("0000-00-00").equals(dateString_tDBInput_2)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_2)) {
									row1.date = rs_tDBInput_2.getTimestamp(3);
								} else {
									row1.date = (java.util.Date) year0_tDBInput_2.clone();
								}
							} else {
								row1.date = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 4) {
							row1.price = null;
						} else {

							row1.price = rs_tDBInput_2.getFloat(4);
							if (rs_tDBInput_2.wasNull()) {
								row1.price = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 5) {
							row1.duration = null;
						} else {

							row1.duration = rs_tDBInput_2.getDouble(5);
							if (rs_tDBInput_2.wasNull()) {
								row1.duration = null;
							}
						}
						if (colQtyInRs_tDBInput_2 < 6) {
							row1.hospital_name = null;
						} else {

							row1.hospital_name = routines.system.JDBCUtil.getString(rs_tDBInput_2, 6, false);
						}
						if (colQtyInRs_tDBInput_2 < 7) {
							row1.city = null;
						} else {

							row1.city = routines.system.JDBCUtil.getString(rs_tDBInput_2, 7, false);
						}
						if (colQtyInRs_tDBInput_2 < 8) {
							row1.country = null;
						} else {

							row1.country = routines.system.JDBCUtil.getString(rs_tDBInput_2, 8, false);
						}
						if (colQtyInRs_tDBInput_2 < 9) {
							row1.person_first_name = null;
						} else {

							row1.person_first_name = routines.system.JDBCUtil.getString(rs_tDBInput_2, 9, false);
						}
						if (colQtyInRs_tDBInput_2 < 10) {
							row1.person_last_name = null;
						} else {

							row1.person_last_name = routines.system.JDBCUtil.getString(rs_tDBInput_2, 10, false);
						}
						if (colQtyInRs_tDBInput_2 < 11) {
							row1.job = null;
						} else {

							row1.job = routines.system.JDBCUtil.getString(rs_tDBInput_2, 11, false);
						}
						if (colQtyInRs_tDBInput_2 < 12) {
							row1.marital_status = null;
						} else {

							row1.marital_status = routines.system.JDBCUtil.getString(rs_tDBInput_2, 12, false);
						}
						if (colQtyInRs_tDBInput_2 < 13) {
							row1.gender = null;
						} else {

							row1.gender = routines.system.JDBCUtil.getString(rs_tDBInput_2, 13, false);
						}

						/**
						 * [tDBInput_2 begin ] stop
						 */

						/**
						 * [tDBInput_2 main ] start
						 */

						currentComponent = "tDBInput_2";

						tos_count_tDBInput_2++;

						/**
						 * [tDBInput_2 main ] stop
						 */

						/**
						 * [tDBInput_2 process_data_begin ] start
						 */

						currentComponent = "tDBInput_2";

						/**
						 * [tDBInput_2 process_data_begin ] stop
						 */

						/**
						 * [tJoin_1 main ] start
						 */

						currentComponent = "tJoin_1";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row1"

							);
						}

						row3 = null;

						row3 = new row3Struct();
						row3.id = row1.id;
						row3.idpatient = row1.date;

						if (util_tJoin_1.isJoined(row1)) {
							row3.iddoctor = util_tJoin_1.lookupValue.id;
						}

///////////////////////    			

						tos_count_tJoin_1++;

						/**
						 * [tJoin_1 main ] stop
						 */

						/**
						 * [tJoin_1 process_data_begin ] start
						 */

						currentComponent = "tJoin_1";

						/**
						 * [tJoin_1 process_data_begin ] stop
						 */
// Start of branch "row3"
						if (row3 != null) {

							/**
							 * [tJoin_2 main ] start
							 */

							currentComponent = "tJoin_2";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row3"

								);
							}

							row5 = null;

							row5 = new row5Struct();
							row5.id = row3.id;
							row5.iddoctor = row3.iddoctor;

							if (util_tJoin_2.isJoined(row3)) {
								row5.idpatient = util_tJoin_2.lookupValue.idpatient;
							}

///////////////////////    			

							tos_count_tJoin_2++;

							/**
							 * [tJoin_2 main ] stop
							 */

							/**
							 * [tJoin_2 process_data_begin ] start
							 */

							currentComponent = "tJoin_2";

							/**
							 * [tJoin_2 process_data_begin ] stop
							 */
// Start of branch "row5"
							if (row5 != null) {

								/**
								 * [tLogRow_1 main ] start
								 */

								currentComponent = "tLogRow_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "row5"

									);
								}

///////////////////////		

								strBuffer_tLogRow_1 = new StringBuilder();

								if (row5.id != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row5.id));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row5.iddoctor != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row5.iddoctor));

								} //

								strBuffer_tLogRow_1.append("|");

								if (row5.idpatient != null) { //

									strBuffer_tLogRow_1.append(String.valueOf(row5.idpatient));

								} //

								if (globalMap.get("tLogRow_CONSOLE") != null) {
									consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
								} else {
									consoleOut_tLogRow_1 = new java.io.PrintStream(
											new java.io.BufferedOutputStream(System.out));
									globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
								}
								consoleOut_tLogRow_1.println(strBuffer_tLogRow_1.toString());
								consoleOut_tLogRow_1.flush();
								nb_line_tLogRow_1++;
//////

//////                    

///////////////////////    			

								tos_count_tLogRow_1++;

								/**
								 * [tLogRow_1 main ] stop
								 */

								/**
								 * [tLogRow_1 process_data_begin ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_begin ] stop
								 */

								/**
								 * [tLogRow_1 process_data_end ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_end ] stop
								 */

							} // End of branch "row5"

							/**
							 * [tJoin_2 process_data_end ] start
							 */

							currentComponent = "tJoin_2";

							/**
							 * [tJoin_2 process_data_end ] stop
							 */

						} // End of branch "row3"

						/**
						 * [tJoin_1 process_data_end ] start
						 */

						currentComponent = "tJoin_1";

						/**
						 * [tJoin_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 process_data_end ] start
						 */

						currentComponent = "tDBInput_2";

						/**
						 * [tDBInput_2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 end ] start
						 */

						currentComponent = "tDBInput_2";

					}
				} finally {
					if (rs_tDBInput_2 != null) {
						rs_tDBInput_2.close();
					}
					if (stmt_tDBInput_2 != null) {
						stmt_tDBInput_2.close();
					}
					if (conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {

						conn_tDBInput_2.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}

				}

				globalMap.put("tDBInput_2_NB_LINE", nb_line_tDBInput_2);

				ok_Hash.put("tDBInput_2", true);
				end_Hash.put("tDBInput_2", System.currentTimeMillis());

				/**
				 * [tDBInput_2 end ] stop
				 */

				/**
				 * [tJoin_1 end ] start
				 */

				currentComponent = "tJoin_1";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tJoin_1", true);
				end_Hash.put("tJoin_1", System.currentTimeMillis());

				/**
				 * [tJoin_1 end ] stop
				 */

				/**
				 * [tJoin_2 end ] start
				 */

				currentComponent = "tJoin_2";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row3");
				}

				ok_Hash.put("tJoin_2", true);
				end_Hash.put("tJoin_2", System.currentTimeMillis());

				/**
				 * [tJoin_2 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

//////
//////
				globalMap.put("tLogRow_1_NB_LINE", nb_line_tLogRow_1);

///////////////////////    			

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row5");
				}

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tJoin_2"
			globalMap.remove("tHash_row4");

			// free memory for "tJoin_1"
			globalMap.remove("tHash_row2");

			try {

				/**
				 * [tDBInput_2 finally ] start
				 */

				currentComponent = "tDBInput_2";

				/**
				 * [tDBInput_2 finally ] stop
				 */

				/**
				 * [tJoin_1 finally ] start
				 */

				currentComponent = "tJoin_1";

				/**
				 * [tJoin_1 finally ] stop
				 */

				/**
				 * [tJoin_2 finally ] start
				 */

				currentComponent = "tJoin_2";

				/**
				 * [tJoin_2 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				/**
				 * [tLogRow_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}

	public static class row4Struct implements routines.system.IPersistableComparableLookupRow<row4Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_jobconsultation2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_jobconsultation2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer idpatient;

		public Integer getIdpatient() {
			return this.idpatient;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public String person_full_name;

		public String getPerson_full_name() {
			return this.person_full_name;
		}

		public String person_age_range;

		public String getPerson_age_range() {
			return this.person_age_range;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String weight_range;

		public String getWeight_range() {
			return this.weight_range;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.person_first_name == null) ? 0 : this.person_first_name.hashCode());

				result = prime * result + ((this.person_last_name == null) ? 0 : this.person_last_name.hashCode());

				result = prime * result + ((this.gender == null) ? 0 : this.gender.hashCode());

				result = prime * result + ((this.marital_status == null) ? 0 : this.marital_status.hashCode());

				result = prime * result + ((this.job == null) ? 0 : this.job.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row4Struct other = (row4Struct) obj;

			if (this.person_first_name == null) {
				if (other.person_first_name != null)
					return false;

			} else if (!this.person_first_name.equals(other.person_first_name))

				return false;

			if (this.person_last_name == null) {
				if (other.person_last_name != null)
					return false;

			} else if (!this.person_last_name.equals(other.person_last_name))

				return false;

			if (this.gender == null) {
				if (other.gender != null)
					return false;

			} else if (!this.gender.equals(other.gender))

				return false;

			if (this.marital_status == null) {
				if (other.marital_status != null)
					return false;

			} else if (!this.marital_status.equals(other.marital_status))

				return false;

			if (this.job == null) {
				if (other.job != null)
					return false;

			} else if (!this.job.equals(other.job))

				return false;

			return true;
		}

		public void copyDataTo(row4Struct other) {

			other.idpatient = this.idpatient;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_full_name = this.person_full_name;
			other.person_age_range = this.person_age_range;
			other.gender = this.gender;
			other.marital_status = this.marital_status;
			other.job = this.job;
			other.weight_range = this.weight_range;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(row4Struct other) {

			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.gender = this.gender;
			other.marital_status = this.marital_status;
			other.job = this.job;

		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.gender = readString(dis);

					this.marital_status = readString(dis);

					this.job = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.person_first_name = readString(dis);

					this.person_last_name = readString(dis);

					this.gender = readString(dis);

					this.marital_status = readString(dis);

					this.job = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// String

				writeString(this.gender, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.job, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.person_first_name, dos);

				// String

				writeString(this.person_last_name, dos);

				// String

				writeString(this.gender, dos);

				// String

				writeString(this.marital_status, dos);

				// String

				writeString(this.job, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.idpatient = readInteger(dis, ois);

				this.person_full_name = readString(dis, ois);

				this.person_age_range = readString(dis, ois);

				this.weight_range = readString(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.practice_sport = null;
				} else {
					this.practice_sport = dis.readBoolean();
				}

				length = dis.readByte();
				if (length == -1) {
					this.smokes = null;
				} else {
					this.smokes = dis.readBoolean();
				}

				length = dis.readByte();
				if (length == -1) {
					this.alcohol = null;
				} else {
					this.alcohol = dis.readBoolean();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.idpatient = readInteger(dis, objectIn);

				this.person_full_name = readString(dis, objectIn);

				this.person_age_range = readString(dis, objectIn);

				this.weight_range = readString(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.practice_sport = null;
				} else {
					this.practice_sport = objectIn.readBoolean();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.smokes = null;
				} else {
					this.smokes = objectIn.readBoolean();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.alcohol = null;
				} else {
					this.alcohol = objectIn.readBoolean();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeInteger(this.idpatient, dos, oos);

				writeString(this.person_full_name, dos, oos);

				writeString(this.person_age_range, dos, oos);

				writeString(this.weight_range, dos, oos);

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeInteger(this.idpatient, dos, objectOut);

				writeString(this.person_full_name, dos, objectOut);

				writeString(this.person_age_range, dos, objectOut);

				writeString(this.weight_range, dos, objectOut);

				if (this.practice_sport == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeBoolean(this.practice_sport);
				}

				if (this.smokes == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeBoolean(this.smokes);
				}

				if (this.alcohol == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("idpatient=" + String.valueOf(idpatient));
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_full_name=" + person_full_name);
			sb.append(",person_age_range=" + person_age_range);
			sb.append(",gender=" + gender);
			sb.append(",marital_status=" + marital_status);
			sb.append(",job=" + job);
			sb.append(",weight_range=" + weight_range);
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.person_first_name, other.person_first_name);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.person_last_name, other.person_last_name);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.gender, other.gender);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.marital_status, other.marital_status);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.job, other.job);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row4Struct row4 = new row4Struct();

				/**
				 * [tHash_row4 begin ] start
				 */

				ok_Hash.put("tHash_row4", false);
				start_Hash.put("tHash_row4", System.currentTimeMillis());

				currentComponent = "tHash_row4";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row4");
				}

				int tos_count_tHash_row4 = 0;

				java.util.Map<row4Struct, row4Struct> tHash_row4 = new java.util.LinkedHashMap<row4Struct, row4Struct>();
				globalMap.put("tHash_row4", tHash_row4);

				/**
				 * [tHash_row4 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
				calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "com.mysql.cj.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "root";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil
						.decryptPassword("enc:routine.encryption.key.v1:argxl7klq/kwv2Ht/F1GqcM4vu11BE9QeoDqdg==");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String properties_tDBInput_1 = "noDatetimeStringSync=true";
				if (properties_tDBInput_1 == null || properties_tDBInput_1.trim().length() == 0) {
					properties_tDBInput_1 = "";
				}
				String url_tDBInput_1 = "jdbc:mysql://" + "localhost" + ":" + "3306" + "/" + "datawarehouse" + "?"
						+ properties_tDBInput_1;

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "select * from patienttdimension";

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row4.idpatient = null;
						} else {

							row4.idpatient = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								row4.idpatient = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row4.person_first_name = null;
						} else {

							row4.person_first_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 2, false);
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row4.person_last_name = null;
						} else {

							row4.person_last_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, false);
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row4.person_full_name = null;
						} else {

							row4.person_full_name = routines.system.JDBCUtil.getString(rs_tDBInput_1, 4, false);
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row4.person_age_range = null;
						} else {

							row4.person_age_range = routines.system.JDBCUtil.getString(rs_tDBInput_1, 5, false);
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row4.gender = null;
						} else {

							row4.gender = routines.system.JDBCUtil.getString(rs_tDBInput_1, 6, false);
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row4.marital_status = null;
						} else {

							row4.marital_status = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, false);
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row4.job = null;
						} else {

							row4.job = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row4.weight_range = null;
						} else {

							row4.weight_range = routines.system.JDBCUtil.getString(rs_tDBInput_1, 9, false);
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row4.practice_sport = null;
						} else {

							row4.practice_sport = rs_tDBInput_1.getBoolean(10);
							if (rs_tDBInput_1.wasNull()) {
								row4.practice_sport = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 11) {
							row4.smokes = null;
						} else {

							row4.smokes = rs_tDBInput_1.getBoolean(11);
							if (rs_tDBInput_1.wasNull()) {
								row4.smokes = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 12) {
							row4.alcohol = null;
						} else {

							row4.alcohol = rs_tDBInput_1.getBoolean(12);
							if (rs_tDBInput_1.wasNull()) {
								row4.alcohol = null;
							}
						}

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tHash_row4 main ] start
						 */

						currentComponent = "tHash_row4";

						if (execStat) {
							runStat.updateStatOnConnection(iterateId, 1, 1

									, "row4"

							);
						}

						row4Struct row4_HashRow = new row4Struct();

						row4_HashRow.idpatient = row4.idpatient;
						row4_HashRow.person_first_name = row4.person_first_name;
						row4_HashRow.person_last_name = row4.person_last_name;
						row4_HashRow.person_full_name = row4.person_full_name;
						row4_HashRow.person_age_range = row4.person_age_range;
						row4_HashRow.gender = row4.gender;
						row4_HashRow.marital_status = row4.marital_status;
						row4_HashRow.job = row4.job;
						row4_HashRow.weight_range = row4.weight_range;
						row4_HashRow.practice_sport = row4.practice_sport;
						row4_HashRow.smokes = row4.smokes;
						row4_HashRow.alcohol = row4.alcohol;
						tHash_row4.put(row4_HashRow, row4_HashRow);

						tos_count_tHash_row4++;

						/**
						 * [tHash_row4 main ] stop
						 */

						/**
						 * [tHash_row4 process_data_begin ] start
						 */

						currentComponent = "tHash_row4";

						/**
						 * [tHash_row4 process_data_begin ] stop
						 */

						/**
						 * [tHash_row4 process_data_end ] start
						 */

						currentComponent = "tHash_row4";

						/**
						 * [tHash_row4 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

					}

				}

				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tHash_row4 end ] start
				 */

				currentComponent = "tHash_row4";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row4");
				}

				ok_Hash.put("tHash_row4", true);
				end_Hash.put("tHash_row4", System.currentTimeMillis());

				/**
				 * [tHash_row4 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tHash_row4 finally ] start
				 */

				currentComponent = "tHash_row4";

				/**
				 * [tHash_row4 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public static class row2Struct implements routines.system.IPersistableComparableLookupRow<row2Struct> {
		final static byte[] commonByteArrayLock_PROJET_DATA_jobconsultation2 = new byte[0];
		static byte[] commonByteArray_PROJET_DATA_jobconsultation2 = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer id;

		public Integer getId() {
			return this.id;
		}

		public java.util.Date date;

		public java.util.Date getDate() {
			return this.date;
		}

		public Float price;

		public Float getPrice() {
			return this.price;
		}

		public Double duration;

		public Double getDuration() {
			return this.duration;
		}

		public String doctor_first_name;

		public String getDoctor_first_name() {
			return this.doctor_first_name;
		}

		public String doctor_last_name;

		public String getDoctor_last_name() {
			return this.doctor_last_name;
		}

		public Integer doctor_age;

		public Integer getDoctor_age() {
			return this.doctor_age;
		}

		public String specialty;

		public String getSpecialty() {
			return this.specialty;
		}

		public Integer experience;

		public Integer getExperience() {
			return this.experience;
		}

		public String hospital_name;

		public String getHospital_name() {
			return this.hospital_name;
		}

		public String city;

		public String getCity() {
			return this.city;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String person_first_name;

		public String getPerson_first_name() {
			return this.person_first_name;
		}

		public String person_last_name;

		public String getPerson_last_name() {
			return this.person_last_name;
		}

		public Integer person_age;

		public Integer getPerson_age() {
			return this.person_age;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String marital_status;

		public String getMarital_status() {
			return this.marital_status;
		}

		public String gender;

		public String getGender() {
			return this.gender;
		}

		public Float weight;

		public Float getWeight() {
			return this.weight;
		}

		public Boolean practice_sport;

		public Boolean getPractice_sport() {
			return this.practice_sport;
		}

		public Boolean smokes;

		public Boolean getSmokes() {
			return this.smokes;
		}

		public Boolean alcohol;

		public Boolean getAlcohol() {
			return this.alcohol;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.doctor_first_name == null) ? 0 : this.doctor_first_name.hashCode());

				result = prime * result + ((this.doctor_last_name == null) ? 0 : this.doctor_last_name.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row2Struct other = (row2Struct) obj;

			if (this.doctor_first_name == null) {
				if (other.doctor_first_name != null)
					return false;

			} else if (!this.doctor_first_name.equals(other.doctor_first_name))

				return false;

			if (this.doctor_last_name == null) {
				if (other.doctor_last_name != null)
					return false;

			} else if (!this.doctor_last_name.equals(other.doctor_last_name))

				return false;

			return true;
		}

		public void copyDataTo(row2Struct other) {

			other.id = this.id;
			other.date = this.date;
			other.price = this.price;
			other.duration = this.duration;
			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;
			other.doctor_age = this.doctor_age;
			other.specialty = this.specialty;
			other.experience = this.experience;
			other.hospital_name = this.hospital_name;
			other.city = this.city;
			other.country = this.country;
			other.person_first_name = this.person_first_name;
			other.person_last_name = this.person_last_name;
			other.person_age = this.person_age;
			other.job = this.job;
			other.marital_status = this.marital_status;
			other.gender = this.gender;
			other.weight = this.weight;
			other.practice_sport = this.practice_sport;
			other.smokes = this.smokes;
			other.alcohol = this.alcohol;

		}

		public void copyKeysDataTo(row2Struct other) {

			other.doctor_first_name = this.doctor_first_name;
			other.doctor_last_name = this.doctor_last_name;

		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_PROJET_DATA_jobconsultation2.length) {
					if (length < 1024 && commonByteArray_PROJET_DATA_jobconsultation2.length == 0) {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[1024];
					} else {
						commonByteArray_PROJET_DATA_jobconsultation2 = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_PROJET_DATA_jobconsultation2, 0, length);
				strReturn = new String(commonByteArray_PROJET_DATA_jobconsultation2, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_PROJET_DATA_jobconsultation2) {

				try {

					int length = 0;

					this.doctor_first_name = readString(dis);

					this.doctor_last_name = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.doctor_first_name, dos);

				// String

				writeString(this.doctor_last_name, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.id = readInteger(dis, ois);

				this.date = readDate(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.price = null;
				} else {
					this.price = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.duration = null;
				} else {
					this.duration = dis.readDouble();
				}

				this.doctor_age = readInteger(dis, ois);

				this.specialty = readString(dis, ois);

				this.experience = readInteger(dis, ois);

				this.hospital_name = readString(dis, ois);

				this.city = readString(dis, ois);

				this.country = readString(dis, ois);

				this.person_first_name = readString(dis, ois);

				this.person_last_name = readString(dis, ois);

				this.person_age = readInteger(dis, ois);

				this.job = readString(dis, ois);

				this.marital_status = readString(dis, ois);

				this.gender = readString(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.weight = null;
				} else {
					this.weight = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.practice_sport = null;
				} else {
					this.practice_sport = dis.readBoolean();
				}

				length = dis.readByte();
				if (length == -1) {
					this.smokes = null;
				} else {
					this.smokes = dis.readBoolean();
				}

				length = dis.readByte();
				if (length == -1) {
					this.alcohol = null;
				} else {
					this.alcohol = dis.readBoolean();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.id = readInteger(dis, objectIn);

				this.date = readDate(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.price = null;
				} else {
					this.price = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.duration = null;
				} else {
					this.duration = objectIn.readDouble();
				}

				this.doctor_age = readInteger(dis, objectIn);

				this.specialty = readString(dis, objectIn);

				this.experience = readInteger(dis, objectIn);

				this.hospital_name = readString(dis, objectIn);

				this.city = readString(dis, objectIn);

				this.country = readString(dis, objectIn);

				this.person_first_name = readString(dis, objectIn);

				this.person_last_name = readString(dis, objectIn);

				this.person_age = readInteger(dis, objectIn);

				this.job = readString(dis, objectIn);

				this.marital_status = readString(dis, objectIn);

				this.gender = readString(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.weight = null;
				} else {
					this.weight = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.practice_sport = null;
				} else {
					this.practice_sport = objectIn.readBoolean();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.smokes = null;
				} else {
					this.smokes = objectIn.readBoolean();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.alcohol = null;
				} else {
					this.alcohol = objectIn.readBoolean();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeInteger(this.id, dos, oos);

				writeDate(this.date, dos, oos);

				if (this.price == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.price);
				}

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.duration);
				}

				writeInteger(this.doctor_age, dos, oos);

				writeString(this.specialty, dos, oos);

				writeInteger(this.experience, dos, oos);

				writeString(this.hospital_name, dos, oos);

				writeString(this.city, dos, oos);

				writeString(this.country, dos, oos);

				writeString(this.person_first_name, dos, oos);

				writeString(this.person_last_name, dos, oos);

				writeInteger(this.person_age, dos, oos);

				writeString(this.job, dos, oos);

				writeString(this.marital_status, dos, oos);

				writeString(this.gender, dos, oos);

				if (this.weight == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.weight);
				}

				if (this.practice_sport == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.practice_sport);
				}

				if (this.smokes == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.smokes);
				}

				if (this.alcohol == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeInteger(this.id, dos, objectOut);

				writeDate(this.date, dos, objectOut);

				if (this.price == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.price);
				}

				if (this.duration == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeDouble(this.duration);
				}

				writeInteger(this.doctor_age, dos, objectOut);

				writeString(this.specialty, dos, objectOut);

				writeInteger(this.experience, dos, objectOut);

				writeString(this.hospital_name, dos, objectOut);

				writeString(this.city, dos, objectOut);

				writeString(this.country, dos, objectOut);

				writeString(this.person_first_name, dos, objectOut);

				writeString(this.person_last_name, dos, objectOut);

				writeInteger(this.person_age, dos, objectOut);

				writeString(this.job, dos, objectOut);

				writeString(this.marital_status, dos, objectOut);

				writeString(this.gender, dos, objectOut);

				if (this.weight == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.weight);
				}

				if (this.practice_sport == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeBoolean(this.practice_sport);
				}

				if (this.smokes == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeBoolean(this.smokes);
				}

				if (this.alcohol == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeBoolean(this.alcohol);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",date=" + String.valueOf(date));
			sb.append(",price=" + String.valueOf(price));
			sb.append(",duration=" + String.valueOf(duration));
			sb.append(",doctor_first_name=" + doctor_first_name);
			sb.append(",doctor_last_name=" + doctor_last_name);
			sb.append(",doctor_age=" + String.valueOf(doctor_age));
			sb.append(",specialty=" + specialty);
			sb.append(",experience=" + String.valueOf(experience));
			sb.append(",hospital_name=" + hospital_name);
			sb.append(",city=" + city);
			sb.append(",country=" + country);
			sb.append(",person_first_name=" + person_first_name);
			sb.append(",person_last_name=" + person_last_name);
			sb.append(",person_age=" + String.valueOf(person_age));
			sb.append(",job=" + job);
			sb.append(",marital_status=" + marital_status);
			sb.append(",gender=" + gender);
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",practice_sport=" + String.valueOf(practice_sport));
			sb.append(",smokes=" + String.valueOf(smokes));
			sb.append(",alcohol=" + String.valueOf(alcohol));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.doctor_first_name, other.doctor_first_name);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.doctor_last_name, other.doctor_last_name);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();

				/**
				 * [tHash_row2 begin ] start
				 */

				ok_Hash.put("tHash_row2", false);
				start_Hash.put("tHash_row2", System.currentTimeMillis());

				currentComponent = "tHash_row2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row2");
				}

				int tos_count_tHash_row2 = 0;

				java.util.Map<row2Struct, row2Struct> tHash_row2 = new java.util.LinkedHashMap<row2Struct, row2Struct>();
				globalMap.put("tHash_row2", tHash_row2);

				/**
				 * [tHash_row2 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "C://Users//pc//Desktop//projet datawarehouse//tous.csv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"C://Users//pc//Desktop//projet datawarehouse//tous.csv", "ISO-8859-15", ",", "\n",
								true, 1, 0, limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						row2 = null;

						row2 = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						row2 = new row2Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.id = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"id", "row2", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}

							} else {

								row2.id = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 1;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.date = ParserUtils.parseTo_Date(temp, "yyyy-MM-dd");

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"date", "row2", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}

							} else {

								row2.date = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 2;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.price = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"price", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.price = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 3;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.duration = ParserUtils.parseTo_Double(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"duration", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.duration = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 4;

							row2.doctor_first_name = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 5;

							row2.doctor_last_name = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 6;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.doctor_age = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"doctor_age", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.doctor_age = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 7;

							row2.specialty = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 8;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.experience = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"experience", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.experience = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 9;

							row2.hospital_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 10;

							row2.city = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 11;

							row2.country = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 12;

							row2.person_first_name = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 13;

							row2.person_last_name = fid_tFileInputDelimited_1
									.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 14;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.person_age = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"person_age", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.person_age = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 15;

							row2.job = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 16;

							row2.marital_status = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 17;

							row2.gender = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 18;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.weight = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"weight", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.weight = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 19;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.practice_sport = ParserUtils.parseTo_Boolean(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"practice_sport", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.practice_sport = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 20;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.smokes = ParserUtils.parseTo_Boolean(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"smokes", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.smokes = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 21;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									row2.alcohol = ParserUtils.parseTo_Boolean(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"alcohol", "row2", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								row2.alcohol = null;

							}

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							System.err.println(e.getMessage());
							row2 = null;

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "row2"
						if (row2 != null) {

							/**
							 * [tHash_row2 main ] start
							 */

							currentComponent = "tHash_row2";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row2"

								);
							}

							row2Struct row2_HashRow = new row2Struct();

							row2_HashRow.id = row2.id;
							row2_HashRow.date = row2.date;
							row2_HashRow.price = row2.price;
							row2_HashRow.duration = row2.duration;
							row2_HashRow.doctor_first_name = row2.doctor_first_name;
							row2_HashRow.doctor_last_name = row2.doctor_last_name;
							row2_HashRow.doctor_age = row2.doctor_age;
							row2_HashRow.specialty = row2.specialty;
							row2_HashRow.experience = row2.experience;
							row2_HashRow.hospital_name = row2.hospital_name;
							row2_HashRow.city = row2.city;
							row2_HashRow.country = row2.country;
							row2_HashRow.person_first_name = row2.person_first_name;
							row2_HashRow.person_last_name = row2.person_last_name;
							row2_HashRow.person_age = row2.person_age;
							row2_HashRow.job = row2.job;
							row2_HashRow.marital_status = row2.marital_status;
							row2_HashRow.gender = row2.gender;
							row2_HashRow.weight = row2.weight;
							row2_HashRow.practice_sport = row2.practice_sport;
							row2_HashRow.smokes = row2.smokes;
							row2_HashRow.alcohol = row2.alcohol;
							tHash_row2.put(row2_HashRow, row2_HashRow);

							tos_count_tHash_row2++;

							/**
							 * [tHash_row2 main ] stop
							 */

							/**
							 * [tHash_row2 process_data_begin ] start
							 */

							currentComponent = "tHash_row2";

							/**
							 * [tHash_row2 process_data_begin ] stop
							 */

							/**
							 * [tHash_row2 process_data_end ] start
							 */

							currentComponent = "tHash_row2";

							/**
							 * [tHash_row2 process_data_end ] stop
							 */

						} // End of branch "row2"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) ("C://Users//pc//Desktop//projet datawarehouse//tous.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tHash_row2 end ] start
				 */

				currentComponent = "tHash_row2";

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row2");
				}

				ok_Hash.put("tHash_row2", true);
				end_Hash.put("tHash_row2", System.currentTimeMillis());

				/**
				 * [tHash_row2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tHash_row2 finally ] start
				 */

				currentComponent = "tHash_row2";

				/**
				 * [tHash_row2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final jobconsultation2 jobconsultation2Class = new jobconsultation2();

		int exitCode = jobconsultation2Class.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = jobconsultation2.class.getClassLoader()
					.getResourceAsStream("projet_data/jobconsultation2_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = jobconsultation2.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_2) {
			globalMap.put("tDBInput_2_SUBPROCESS_STATE", -1);

			e_tDBInput_2.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : jobconsultation2");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 161043 characters generated by Talend Open Studio for Data Integration on the
 * 29 novembre 2024, 15:09:00 WAT
 ************************************************************************************************/